#include <stdio.h>
#include <stdlib.h>
#define N 5

void vectorGrados(int A[][N], int V[], int i, int j, int n);

void MuestraVector(int V[], int n);

int main()
{
    int A[][N] = {{1,1,0,0,1},{1,0,1,0,1},{0,1,0,1,0},{0,0,1,1,0},{1,1,0,0,1}}, V[N], n = 5;
    vectorGrados(A,V,n-1,n-1,n-1);
    MuestraVector(V,n);
    return 0;
}

void vectorGrados(int A[][N], int V[], int i, int j, int n)
{
    if (j >= 0)
    {
        if (i == j)
            vectorGrados(A,V,n,j-1,n);
        else
        {
            vectorGrados(A,V,i-1,j,n);
            V[j] += A[i][j];
        }
        V[i] += A[i][j];
    }
    else
        for (i=0;i<=n;i++)
            V[i] = 0;
}

void MuestraVector(int V[], int n)
{
    int i;
    for (i=0;i<n;i++)
        printf("%d\t",V[i]);
}
