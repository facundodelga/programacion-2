#include <stdio.h>
#include <stdlib.h>
#define N 4

void MostrarMatriz(int A[][N], int n, int m);

void GrafoSubyacente(int A[][N],int n);

int main()
{
    int A[][N] = {{0,1,1,0},{0,0,0,1},{1,1,0,0},{0,0,1,0}}, n = 4;
    GrafoSubyacente(A,n);
    MostrarMatriz(A,n,n);
    return 0;
}

void MostrarMatriz(int A[][N], int n, int m)
{
    int i, j;
    for (i=0;i<n;i++)
    {
        for (j=0;j<m;j++)
            printf("%d\t",A[i][j]);
        printf("\n");
    }
}

void GrafoSubyacente(int A[][N],int n)
{
    int i,j;
    for (i=0;i<n;i++)
        for (j=0;j<n;j++)
            if (A[i][j] == 1)
                A[j][i] = 1;
}
