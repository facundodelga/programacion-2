#include <stdio.h>
#include <stdlib.h>
#define N 4

typedef struct nodoL
{
    int dato;
    struct nodoL* sig;
} NodoL;

typedef NodoL* TLista;

int gradoEntradaVert(TLista v[], TLista lista, int j, int x);

void vertMaxGr(TLista v[], int i, int gradoMax, int* vertMax);

int main()
{
    int x = 3, vertMax;
    TLista v[N], lista;
    lista = (TLista) malloc(sizeof(NodoL));
    lista->dato = 0;
    lista->sig = (TLista) malloc(sizeof(NodoL));
    lista->sig->dato = 1;
    lista->sig->sig = (TLista) malloc(sizeof(NodoL));
    lista->sig->sig->dato = 2;
    lista->sig->sig->sig = NULL;
    v[0] = lista;
    lista = (TLista) malloc(sizeof(NodoL));
    lista->dato = 1;
    lista->sig = (TLista) malloc(sizeof(NodoL));
    lista->sig->dato = 3;
    lista->sig->sig = NULL;
    v[1] = lista;
    lista = (TLista) malloc(sizeof(NodoL));
    lista->dato = 2;
    lista->sig = (TLista) malloc(sizeof(NodoL));
    lista->sig->dato = 0;
    lista->sig->sig = (TLista) malloc(sizeof(NodoL));
    lista->sig->sig->dato = 1;
    lista->sig->sig->sig = (TLista) malloc(sizeof(NodoL));
    lista->sig->sig->sig->dato = 3;
    lista->sig->sig->sig->sig = NULL;
    v[2] = lista;
    lista = (TLista) malloc(sizeof(NodoL));
    lista->dato = 3;
    lista->sig = (TLista) malloc(sizeof(NodoL));
    lista->sig->dato = 2;
    lista->sig->sig = (TLista) malloc(sizeof(NodoL));
    lista->sig->sig->dato = 3;
    lista->sig->sig->sig = NULL;
    v[3] = lista;
    vertMaxGr(v,0,0,&vertMax);
    printf("El vertice de grado maximo es %d.", vertMax);
}

int gradoEntradaVert(TLista v[], TLista lista, int j, int x)
{
    if (j<N)
        if (lista == NULL)
            return gradoEntradaVert(v,v[j+1],j+1,x);
        else
            if ((lista->dato == x) && (lista != v[j]))
                return 1 + gradoEntradaVert(v,v[j+1],j+1,x);
            else
                return gradoEntradaVert(v,lista->sig,j,x);
    else
        return 0;

}

void vertMaxGr(TLista v[], int i, int gradoMax, int* vertMax)
{
    int grado;
    if (i < N)
    {
        grado = gradoEntradaVert(v,v[0],0,i);
        if (grado > gradoMax)
        {
            *vertMax = i;
            gradoMax = grado;
        }
        vertMaxGr(v,i+1,gradoMax,vertMax);
    }
}
