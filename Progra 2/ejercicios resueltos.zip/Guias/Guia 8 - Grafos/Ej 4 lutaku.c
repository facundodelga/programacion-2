#include <stdio.h>
#include <stdlib.h>
#define N 4

void subyacente(int A[][N],int n);

int main()
{
    int A[N][N]={{0,1,1,0},{0,0,0,1},{1,1,0,0},{0,0,1,0}},n=4;
    subyacente(A,n);
    return 0;
}

void subyacente(int A[][N],int n)
{
    int i,j;
    for (i=0;i<n;i++)
        for (j=i;j<n;j++)
            if (A[i][j]!=A[j][i] || A[i][j]>0)
                A[i][j]=A[j][i]=A[i][j]+A[j][i];
}
