#include <stdio.h>
#include <stdlib.h>
#define N 5
#include "PilaD.h"
#include "ColaD.h"

void Prof(int A[][N], int n);

void Amp(int A[][N], int n);

int main()
{
    int A[][N] = {{1,1,0,0,1},{1,0,1,0,1},{0,1,0,1,0},{0,0,1,1,0},{1,1,0,0,1}}, V[N], n = 5;
    Prof(A,n);
    printf("\n*****\n");
    Amp(A,n);
    return 0;
}

void Prof(int A[][N], int n)
{
    int i = 0,j, visitados[N] = {0}, vertice = 0, todos = 0, cantConex;
    TPila pila;
    IniciaP(&pila);
    cantConex = 0;
    printf("Profundidad:\n");
    while (!todos)
    {
        cantConex++;
        poneP(&pila, vertice);
        visitados[vertice] = 1;
        printf("%d\t", vertice);
        while (!VaciaP(pila))
        {
            vertice = consultaP(pila);
            j = 0;
            while ((j<n) && ((A[vertice][j] == 0) || (visitados[j] == 1)))
                j++;
            if (j<n)
            {
                poneP(&pila,j);
                visitados[j] = 1;
                printf("%d\t",j);
            }
            else
                sacaP(&pila,&vertice);
        }
        while ((i<n) && (visitados[i] == 1))
            i++;
        if (i==n)
            todos = 1;
        else
            vertice = i;
    }
    printf("\nLa cantidad de componentes conexas del grafo es: %d",cantConex);
}

void Amp(int A[][N], int n)
{
    int i = 0, j, vertice = 0, visitados[N] = {0}, todos = 0;
    TCola cola;
    IniciaC(&cola);
    printf("Amplitud:\n");
    while (!todos)
    {
        poneC(&cola,vertice);
        visitados[vertice] = 1;
        printf("%d\t",vertice);
        while (!VaciaC(cola))
        {
            sacaC(&cola,&vertice);
            for (j=0;j<n;j++)
                if ((A[vertice][j] != 0) && (visitados[j] == 0))
                {
                    poneC(&cola, j);
                    visitados[j] = 1;
                    printf("%d\t",j);
                }
        }
        while ((i<n) && (visitados[i] == 1))
            i++;
        if (i==n)
            todos = 1;
        else
            vertice = i;
    }
}
