#include <stdio.h>
#include <stdlib.h>
#define N 4

void MostrarMatriz(int A[][N], int n, int m);

int gradoEntrada(int A[][N], int n, int v);

int gradoSalida(int A[][N], int n, int v);

int gradoTotal(int A[][N], int n, int v);

int main()
{
    int A[][N] = {{0,1,1,0},{0,0,0,1},{1,1,0,0},{0,0,1,0}}, n = 4,v;
    printf("Ingrese un vertice a analizar.\n");
    scanf("%d",&v);
    printf("El grado de entrada es: %d\nEl grado de salida es: %d\nEl grado total es: %d\n", gradoEntrada(A,n,v-1), gradoSalida(A,n,v-1), gradoTotal(A,n,v-1));
    return 0;
}

void MostrarMatriz(int A[][N], int n, int m)
{
    int i, j;
    for (i=0;i<n;i++)
    {
        for (j=0;j<m;j++)
            printf("%d\t",A[i][j]);
        printf("\n");
    }
}

int gradoEntrada(int A[][N], int n, int v)
{
    int i, grado = 0;
    for (i=0;i<n;i++)
        if (A[i][v] != 0)
            grado++;
    return grado;
}

int gradoSalida(int A[][N], int n, int v)
{
    int j, grado = 0;
    for (j=0;j<n;j++)
        if (A[v][j] != 0)
            grado++;
    return grado;
}

int gradoTotal(int A[][N], int n, int v)
{
    return gradoEntrada(A,n,v) + gradoSalida(A,n,v) - (A[v][v] != 0);
}
