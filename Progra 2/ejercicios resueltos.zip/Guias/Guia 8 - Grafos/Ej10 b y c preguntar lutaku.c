#include <stdio.h>
#include <stdlib.h>
#include "ColaInt.h"
#define N 7

void Amplitud(int A[][N],int n);

int completa(int V[N],int n);

int main()
{
    int n=7,A[N][N]={{0,1,1,0,0,0,0},{1,0,1,1,0,0,0},{1,1,0,1,1,0,0},{0,1,1,0,1,0,0},{0,0,1,1,0,0,0},{0,0,0,0,0,0,0},{0,0,0,0,0,0,0}};
    Amplitud(A,n);
    return 0;
}

void Amplitud(int A[][N],int n)
{
    int VV[N]={0},vertice=4,j,comp=1;
    TCola c;
    IniciaC(&c);
    poneC(&c,vertice);
    VV[vertice]=1;
    printf("%d ",vertice+1);
    while(!completa(VV,n))
    {
        if(!VaciaC(c))
        {
            sacaC(&c,&vertice);
            for (j=0;j<n;j++)
                if (A[vertice][j]>0 && VV[j]==0)
                    {
                        poneC(&c,j);
                        VV[j]=comp;
                        printf("%d ",j+1);
                    }
        }
        else
        {
            comp++;
            j=0;
            while(VV[j]!=0)
                j++;
            VV[j]=comp;
            printf("%d ",j+1);
            poneC(&c,j);
        }
    }
    printf("cantidad de componentes son %d",comp);
}
int completa(int V[N],int n)
{
    int i=0,bandera=1;
    while (i<n && bandera)
    {
        if (V[i]==0)
            bandera=0;
        i++;
    }
    return bandera;
}
