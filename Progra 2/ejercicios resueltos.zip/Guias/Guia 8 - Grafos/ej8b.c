#include <stdio.h>
#include <stdlib.h>
#define N 4

int maxGrEnt(int A[][N], int i, int j, int n, int cont, int maxGr,int maxV);

int main()
{
    int A[][N] = {{0,1,1,0},{0,0,0,1},{1,1,0,0},{0,0,1,0}}, n = 4;
    printf("El vertice con mayor grado de entrada es: %d\n", maxGrEnt(A,0,0,n,0,-1,-1));
    return 0;
}

int maxGrEnt(int A[][N], int i, int j, int n, int cont, int maxGr, int maxV)
{
    if (j<n)
    {
        if (A[i][j] != 0)
            cont++;
        if (i == (n-1))
        {
            if (cont > maxGr)
            {
                maxGr = cont;
                maxV = j;
            }
            return maxGrEnt(A,0,j+1,n,0,maxGr,maxV);
        }
        else
            return maxGrEnt(A,i+1,j,n,cont,maxGr,maxV);
    }
    else
        return maxV;
}
