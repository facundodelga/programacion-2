#include <stdio.h>
#include <stdlib.h>
#include "fraccionarios.h"

int main()
{
    fraccion f1, f2, f3;
    int num1 = 25, den1 = 10, num2 = 32, den2 = 5;
    f1 = crear(num1,den1);
    f2 = crear(num2,den2);
    mostrar(f1);
    printf("     ");
    mostrar(f2);
    printf("\n*****\nnumerador de f1: %d   denominador de f1: %d\n",numerador(f1),denominador(f1));
    f3 = sumar(f1,f2);
    printf("\n*****\nsuma:\n");
    mostrar(f3);
    f3 = restar(f1,f2);
    printf("\n*****\nresta:\n");
    mostrar(f3);
    f3 = multiplicar(f1,f2);
    printf("\n*****\nmultiplicaci�n:\n");
    mostrar(f3);
    f3 = dividir(f1,f2);
    printf("\n*****\ndivisi�n:\n");
    mostrar(f3);
    if (iguales(f1,f2))
        printf("\n*****\nf1 y f2 son iguales\n");
    else
        printf("\n*****\nf1 y f2 son distintos\n");
    f1 = simplificar(f1);
    printf("\n*****\nf1 simplificado es:");
    mostrar(f1);
    return 0;
}
