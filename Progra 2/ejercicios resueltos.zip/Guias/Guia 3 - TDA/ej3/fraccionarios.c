#include <stdlib.h>
#include "fraccionarios.h"

void mostrar(fraccion f)
{
    printf("%d/%d",f.num,f.den);
}

fraccion crear(int num, int den)
{
    fraccion f;
    f.num = num;
    f.den = den;
    return f;
}

int numerador(fraccion f)
{
    return f.num;
}

int denominador(fraccion f)
{
    return f.den;
}

fraccion sumar(fraccion f1, fraccion f2)
{
    fraccion f3;
    if (f1.den == f2.den)
    {
        f3.den = f1.den;
        f3.num = f1.num + f2.num;
    }
    else
    {
        f3.den = f1.den * f2.den;
        f3.num = (f1.num * f2.den) + (f2.num * f1.den);
    }
    return f3;
}

fraccion restar(fraccion f1, fraccion f2)
{
    fraccion f3;
    f3.den = f1.den * f2.den;
    f3.num = (f1.num * f2.den) - (f2.num * f1.den);
    return f3;
}

fraccion multiplicar(fraccion f1, fraccion f2)
{
    fraccion f3;
    f3.den = f1.den * f2.den;
    f3.num = f1.num * f2.num;
    return f3;
}

fraccion dividir(fraccion f1, fraccion f2)
{
    fraccion f3;
    f3.num = f1.num * f2.den;
    f3.den = f2.num * f1.den;
    return f3;
}

fraccion simplificar(fraccion f)
{
    fraccion fs;
    int mcd, a = f.num, b = f.den;
    if (b!=0)
    {
        while (a!=b)
        {
            if (a>b)
                a=a-b;
            else
                b=b-a;
        }
        mcd = a;
        fs.num = f.num / mcd;
        fs.den = f.den / mcd;
    }
    return fs;
}

unsigned int iguales(fraccion f1, fraccion f2)
{
    fraccion ftemp1 = f1, ftemp2 = f2;
    ftemp1 = simplificar(ftemp1);
    ftemp2 = simplificar(ftemp2);
    return ((ftemp1.num==ftemp2.num)&&(ftemp1.den==ftemp2.den))?1:0;
}

