#include <stdio.h>
#include <stdlib.h>
#include "booleano.h"

int main()
{
    tBooleano booleano,booleano2,booleano3,booleano4;
    int a = -87;
    int b = 53;
    booleano = crear(a);
    printf("%u\n",comoEntero(booleano));
    booleano2 = crear(b);
    printf("%u\n",comoEntero(booleano2));
    booleano3 = and(booleano,booleano2);
    printf("%u\n",comoEntero(booleano3));
    booleano4 = or(booleano,booleano2);
    printf("%u\n",comoEntero(booleano4));
    booleano3 = not(booleano);
    printf("%u\n",comoEntero(booleano3));
    a = comoEntero(booleano);
    printf("%u\n",a);
    b = comoEntero(booleano2);
    printf("%u",b);
    return 0;
}
