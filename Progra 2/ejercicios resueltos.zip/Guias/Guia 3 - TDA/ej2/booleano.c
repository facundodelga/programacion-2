#include "booleano.h"
#include <string.h>

tBooleano crear(int a)
{
    return (a==0)?0:1;
}

tBooleano and(tBooleano a, tBooleano b)
{
    return ((a==0)||(b==0))?0:1;
}

tBooleano or(tBooleano a, tBooleano b)
{
    return ((a==0)&&(b==0))?0:1;
}

tBooleano not(tBooleano a)
{
    return (a==1)?0:1;
}

unsigned int comoEntero(tBooleano a)
{
    if (a==1)
        return 1;
    else
        return 0;
}
