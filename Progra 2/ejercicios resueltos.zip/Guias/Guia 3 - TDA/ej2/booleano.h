typedef unsigned int tBooleano;

tBooleano crear(int a);

tBooleano and(tBooleano a, tBooleano b);

tBooleano or(tBooleano a, tBooleano b);

tBooleano not(tBooleano a);

unsigned int comoEntero(tBooleano a);

