#include <stdlib.h>
#include "dupla.h"

tipoDupla crear(int a, int b)
{
   tipoDupla dupla;
   dupla.a = a;
   dupla.b = b;
   return dupla;
}

int primero(tipoDupla dupla)
{
   return dupla.a;
}

int segundo(tipoDupla dupla)
{
   return dupla.b;
}

tipoDupla multiplicar(tipoDupla dupla, int multiplo)
{
   tipoDupla dupla2;
   dupla2.a = dupla.a * multiplo;
   dupla2.b = dupla.b * multiplo;
   return dupla2;
}

tipoDupla adicionar(tipoDupla dupla, int adicion)
{
   tipoDupla dupla2;
   dupla2.a = dupla.a + adicion;
   dupla2.b = dupla.b + adicion;
   return dupla2;
}

tipoDupla sumar(tipoDupla dupla1, tipoDupla dupla2)
{
   tipoDupla dupla3;
   dupla3.a = dupla1.a + dupla2.a;
   dupla3.b = dupla1.b + dupla2.b;
   return dupla3;
}

tipoDupla restar(tipoDupla dupla1, tipoDupla dupla2)
{
   tipoDupla dupla3;
   dupla3.a = dupla1.a - dupla2.a;
   dupla3.b = dupla1.b - dupla2.b;
   return dupla3;
}

