#include <stdio.h>
#include <stdlib.h>
#include "dupla.h"

int main()
{
    int a,b,entero;
    tipoDupla d1, d2, d3;
    printf("Ingrese dos n�meros enteros para la primera dupla.\n");
    scanf("%d %d",&a,&b);
    d1 = crear(a,b);
    printf("Ingrese dos n�meros enteros para la segunda dupla.\n");
    scanf("%d %d",&a,&b);
    d2 = crear(a,b);
    printf("*****\nEl primer elemento de la primera dupla es: %d\n",primero(d1));
    printf("El segundo elemento de la primera dupla es: %d\n",segundo(d1));
    printf("*****\nIngrese un n�mero para multiplicar y adicionar a la segunda dupla.\n");
    scanf("%d", &entero);
    d3 = multiplicar(d2,entero);
    printf("*****\nLa segunda dupla multiplicada por %d es %d | %d.\n",entero,primero(d3),segundo(d3));
    d3 = adicionar(d2,entero);
    printf("La segunda dupla adicionada en %d es %d | %d.\n",entero,primero(d3),segundo(d3));
    d3 = sumar(d1,d2);
    printf("*****\nLa suma de las dos duplas ingresadas es %d | %d.\n",primero(d3),segundo(d3));
    d3 = restar(d1,d2);
    printf("La primera dupla menos la segunda es %d | %d.",primero(d3),segundo(d3));
    return 0;
}
