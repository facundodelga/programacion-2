typedef struct{
    int a,b;
} tipoDupla;

tipoDupla crear(int a, int b);

int primero(tipoDupla dupla);

int segundo(tipoDupla dupla);

tipoDupla multiplicar(tipoDupla dupla, int multiplo);

tipoDupla adicionar(tipoDupla dupla, int adicion);

tipoDupla sumar(tipoDupla dupla1, tipoDupla dupla2);

tipoDupla restar(tipoDupla dupla1, tipoDupla dupla2);
