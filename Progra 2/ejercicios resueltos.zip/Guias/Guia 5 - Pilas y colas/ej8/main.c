#include <stdio.h>
#include "pilaChar.h"

void MuestraPila(TPila *p);

void sumaPilas(TPila *p1, TPila *p2, TPila *p3);

int main() {
    TElementoP num1[] = "501122", num2[] = "710000", aux;
    int largo1 = 0, largo2 = 0, i;
    TPila p1,p2,p3, pAux;
    iniciaP(&p1);
    iniciaP(&p2);
    iniciaP(&p3);
    while (num1[largo1] != '\0')
        largo1++;
    while (num2[largo2] != '\0')
        largo2++;
    if (largo1>largo2)
    {
        for (i=0;i<largo1;i++)
            poneP(&p1,num1[i]);
        for (i=0;i<(largo1-largo2);i++)
            poneP(&p2,'0');
        for (i=0;i<largo2;i++)
            poneP(&p2,num2[i]);
    }
    else
    {
        for (i=0;i<largo2;i++)
            poneP(&p2,num2[i]);
        for (i=0;i<(largo2-largo1);i++)
            poneP(&p1,'0');
        for (i=0;i<largo1;i++)
            poneP(&p1,num1[i]);
    }
    sumaPilas(&p1,&p2,&p3);
    MuestraPila(&p3);
    return 0;
}

void MuestraPila(TPila *p)
{
    TElementoP aux;
    if (!vaciaP(*p))
    {
        sacaP(p,&aux);
        MuestraPila(p);
        printf("%c",aux);
        poneP(p,&aux);
    }
}

void sumaPilas(TPila *p1, TPila *p2, TPila *p3)
{
    TElementoP aux, num1, num2;
    TPila pAux;
    int acarreo = 0;
    iniciaP(&pAux);
    while (!vaciaP(*p1))
    {
        sacaP(p1,&num1);
        sacaP(p2,&num2);
        aux = (num1 - '0') + (num2 - '0') + acarreo;
        if (aux > 9)
        {
            aux -= 10;
            acarreo = 1;
        }
        else
            acarreo = 0;
        aux += '0';
        poneP(&pAux,(aux));
    }
    if (acarreo == 1)
        poneP(&pAux,'1');
    while (!vaciaP(pAux))
    {
        sacaP(&pAux,&aux);
        poneP(p3,aux);
    }
}
