#include <stdio.h>
#include <stdlib.h>

typedef struct
{   char ID[6];
    int Sol;
    int Tiempo;
} TElementoC;
typedef struct nodo{
    TElementoC dato;
    struct nodo *sig;}nodoc;
typedef struct{
    nodoc *pri, *ult;} TCola;
void IniciaC (TCola * C);
int VaciaC (TCola C);
TElementoC consultaC (TCola C);
void sacaC (TCola *C, TElementoC* x);
void poneC (TCola *C, TElementoC x);
