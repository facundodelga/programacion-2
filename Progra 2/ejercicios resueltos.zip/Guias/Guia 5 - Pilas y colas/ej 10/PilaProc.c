#include <stdio.h>
#include <stdlib.h>
#include "PilaProc.h"

void IniciaC (TCola * C){
    C->pri=NULL;
    C->ult=NULL;
}
int VaciaC (TCola C){
    return (C.pri == NULL);
}
TElementoC consultaC (TCola C){
    if (!VaciaC(C))
        return (C.pri->dato);
}
void sacaC (TCola *C, TElementoC* x){
    nodoc *N;
    if (!VaciaC(*C)){
        N = C->pri;
        (*x) = N->dato;
        C->pri = C->pri->sig;
        if (C->pri == NULL)
            C->ult = NULL;
        free(N);
    }
}
void poneC (TCola *C, TElementoC x){
    nodoc *N;
    N =(nodoc *) malloc(sizeof(nodoc));
    N->dato = x;
    N->sig = NULL;
    if (VaciaC(*C))
        C->pri = N;
    else
        C->ult->sig = N;
    C->ult =N;
}
