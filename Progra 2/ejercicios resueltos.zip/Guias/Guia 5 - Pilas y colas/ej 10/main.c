#include <stdio.h>
#include <stdlib.h>
#include "PilaProc.h"

void muestra(TCola *cola);

int main()
{
    TCola cola;
    TElementoC proc;
    FILE *arch;
    int seg=0,cont=0;
    arch=fopen("Procesos.txt","rt");
    if (arch != NULL)
    {
        IniciaC(&cola);
        fscanf(arch,"%6s %d %d\n",proc.ID,&proc.Sol,&proc.Tiempo);
        while (!feof(arch))
        {
            seg += proc.Tiempo;
            cont++;
            poneC(&cola,proc);
            fscanf(arch,"%6s %d %d\n",proc.ID,&proc.Sol,&proc.Tiempo);
        }
    }
    else
        printf("el archivo no existe");
    muestra(&cola);
    printf("El promedio es de:%f",(float)seg/cont);
    fclose(arch);
    return 0;
}

void muestra(TCola *cola)
{
    TElementoC x;
    int tiempo=0;
    while (!VaciaC(*cola))
    {
        sacaC(cola,&x);
        tiempo += x.Tiempo;
        printf("%5s %d %d tiempo transcurrido %d segundos\n", x.ID,x.Sol,x.Tiempo,tiempo);
    }
}
