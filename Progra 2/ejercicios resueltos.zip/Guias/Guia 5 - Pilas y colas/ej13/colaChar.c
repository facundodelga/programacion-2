#include "colaChar.h"
#include <stdlib.h>

void iniciaC(TCola *c)
{
    c->pri = c->ult = NULL;
}

void poneC(TCola *c, TElementoC x)
{
    if (vaciaC(*c))
    {
        c->pri = c->ult = (NodoC*) malloc(sizeof(NodoC));
        c->pri->sig = NULL;
    }
    else
    {
        c->ult->sig = (NodoC*) malloc(sizeof(NodoC));
        c->ult = c->ult->sig;
        c->ult->sig = NULL;
    }
    c->ult->dato = x;
}

void sacaC(TCola *c, TElementoC *x)
{
    NodoC *aux;
    if (!vaciaC(*c))
    {
        aux = c->pri;
        *x = aux->dato;
        c->pri = c->pri->sig;
        free(aux);
    }
}

TElementoC consultaC(TCola c)
{
    if (!vaciaC(c))
        return c.pri->dato;
}

int vaciaC(TCola c)
{
    return (c.pri == NULL);
}
