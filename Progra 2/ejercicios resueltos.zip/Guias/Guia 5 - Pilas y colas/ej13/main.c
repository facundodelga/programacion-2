#include <stdlib.h>
#include <stdio.h>
#include "colaChar.h"
#include "pilaChar.h"

void Palindroma(TCola* c, int n, int* rta);

int main(void) {
    TElementoC car;
    TCola c;
    int n, rta, i;
    iniciaC(&c);
    printf("Ingrese la cantidad de letras de la palabra a analizar.\n");
    scanf("%d ", &n);
    for (i=0;i<n;i++)
    {

        scanf("%c",&car);
        poneC(&c, car);
    }
    Palindroma(&c,n,&rta);
    printf("\n%d", rta);
    return 0;
}

void Palindroma(TCola* c, int n, int* rta)
{
    TPila aux1;
    char elem,elem2;
    int i;
    iniciaP(&aux1);
    if (!vaciaC(*c))
    {
        if (n%2)
        {
            for (i=0;i<n/2;i++)
            {
                sacaC(c,&elem);
                poneP(&aux1,elem);
            }
            sacaC(c,&elem);
        }
        else
        {
            for (i=0;i<=n/2;i++)
            {
                sacaC(c,&elem);
                poneP(&aux1,elem);
            }
        }
        *rta = 1;
        while ((!vaciaP(aux1)) && ((*rta) == 1))
        {
            sacaP(&aux1,&elem);
            sacaC(c,&elem2);
            if (elem != elem2)
                *rta = 0;
        }
    }
}
