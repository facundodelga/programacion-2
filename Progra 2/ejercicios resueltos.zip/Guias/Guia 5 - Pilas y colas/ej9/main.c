#include <stdio.h>
#include "pilaChar.h"

void Balance(TPila *p, int* balan);

int main() {
    TElementoP st1[] = "(((2x4)+9)/7)", st2[] = "((2x4)+9)/7)", st3[] = "(((2x4)+9/7)";
    TPila p1,p2,p3;
    int i, b1, b2, b3;
    iniciaP(&p1);
    iniciaP(&p2);
    iniciaP(&p3);
    i = 0;
    while (st1[i] != '\0')
        poneP(&p1,st1[i++]);
    i = 0;
    while (st2[i] != '\0')
        poneP(&p2,st2[i++]);
    i = 0;
    while (st3[i] != '\0')
        poneP(&p3,st3[i++]);
    Balance(&p1,&b1);
    Balance(&p2,&b2);
    Balance(&p3,&b3);
    if (b1 == 0)
        printf("La expresi�n 1 est� balanceada.\n");
    else
        if (b1 > 0)
            printf("La expresi�n 1 tiene m�s par�ntesis del lado derecho.\n");
        else
            printf("La expresi�n 1 tiene m�s par�ntesis del lado izquierdo.\n");
    if (b2 == 0)
        printf("La expresi�n 2 est� balanceada.\n");
    else
        if (b2 > 0)
            printf("La expresi�n 2 tiene m�s par�ntesis del lado derecho.\n");
        else
            printf("La expresi�n 2 tiene m�s par�ntesis del lado izquierdo.\n");
    if (b3 == 0)
        printf("La expresi�n 3 est� balanceada.\n");
    else
        if (b3 > 0)
            printf("La expresi�n 3 tiene m�s par�ntesis del lado derecho.\n");
        else
            printf("La expresi�n 3 tiene m�s par�ntesis del lado izquierdo.\n");
    return 0;
}

void Balance(TPila *p, int* balan)
{
    TElementoP car;
    if (vaciaP(*p))
        *balan = 0;
    else
    {
        sacaP(p,&car);
        Balance(p,balan);
        if (car == ')')
            (*balan)++;
        else
            if (car == '(')
                (*balan)--;
    }
}
