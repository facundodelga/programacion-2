#include "pilaULongInt.h"
#include <stdlib.h>

void iniciaP(TPila *p)
{
    *p = NULL;
}

void poneP(TPila *p, TElementoP x)
{
    TPila N;
    N = (TPila) malloc(sizeof(NodoP));
    N->dato = x;
    N->sig = *p;
    *p = N;
}

void sacaP(TPila *p, TElementoP *x)
{
    TPila aux;
    if (!(vaciaP(*p)))
    {
        aux = *p;
        *x = (*p)->dato;
        *p = (*p)->sig;
        free(aux);
    }
}

TElementoP consultaP(TPila p)
{
    if (!(vaciaP(p)))
        return p->dato;
}

int vaciaP(TPila p)
{
    return (p == NULL);
}
