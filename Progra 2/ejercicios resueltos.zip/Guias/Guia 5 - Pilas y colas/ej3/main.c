#include <stdio.h>
#include <stdlib.h>
#include "pilaULongInt.h"

void MuestraPila(TPila *pila, unsigned int N);

void MuestraPilaInv(TPila *pila, unsigned int N);

int main()
{
    TElementoP dni;
    TPila votantes;
    FILE *Arch;
    unsigned int N, i;
    Arch = fopen("ej3.txt","rt");
    if (Arch != NULL)
    {
        printf("Ingrese la cantidad de votantes a mostrar.\n");
        scanf("%u",&N);
        iniciaP(&votantes);
        while ((fscanf(Arch,"%lu",&dni)) == 1)
            poneP(&votantes,dni);
        printf("\nej a:\n");
        MuestraPila(&votantes,N);
        printf("\nej b:\n");
        MuestraPilaInv(&votantes,N);
    }
    else
    {
        printf("No se encontr� el archivo ej3.txt");
    }
	fclose(Arch);
    return 0;
}

void MuestraPila(TPila *pila, unsigned int N)
{
    TElementoP aux;
    if (!(vaciaP(*pila)) && N!=0)
    {
        sacaP(pila,&aux);
        printf("%lu\n",aux);
        MuestraPila(pila, N-1);
        poneP(pila,aux);
    }
}

void MuestraPilaInv(TPila *pila, unsigned int N)
{
    TElementoP aux;
    if (!(vaciaP(*pila)) && N!=0)
    {
        sacaP(pila,&aux);
        MuestraPilaInv(pila, N-1);
        printf("%lu\n",aux);
        poneP(pila,aux);
    }
}
