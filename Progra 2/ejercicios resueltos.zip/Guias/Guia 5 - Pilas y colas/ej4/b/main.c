#include <stdio.h>
#include <stdlib.h>
#include "colaInt.h"

void MuestraCola(TCola *cola);

int main()
{
    TElementoC num;
    TCola cola;
    FILE *Arch;
    Arch = fopen("ej4.txt","rt");
    if (Arch != NULL)
    {
        iniciaC(&cola);
        while ((fscanf(Arch,"%d",&num)) == 1)
            poneC(&cola,num);
        MuestraCola(&cola);
    }
    else
    {
        printf("No se encontr� el archivo ej3.txt");
    }
	fclose(Arch);
    return 0;
}

void MuestraCola(TCola *cola)
{
    TElementoC aux;
    if (!vaciaC(*cola))
    {
        sacaC(cola,&aux);
        printf("%d\n",aux);
        MuestraCola(cola);
        poneC(cola,aux);
    }
}
