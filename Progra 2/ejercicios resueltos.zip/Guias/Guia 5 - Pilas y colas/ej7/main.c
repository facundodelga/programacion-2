#include <stdio.h>
#include "pilaInt.h"

void CreaPila(TPila *p);

void CambiaSigno(TPila *pila);

void MuestraPila(TPila *pila);

int main(void) {
    TPila pila;
    iniciaP(&pila);
    CreaPila(&pila);
    CambiaSigno(&pila);
    printf("\n");
    MuestraPila(&pila);
    return 0;
}

void CreaPila(TPila *p)
{
    TElementoP n;
    while(scanf("%d", &n))
        poneP(p, n);
}

void CambiaSigno(TPila *pila)
{
    TElementoP aux;
    if (!vaciaP(*pila))
    {
        sacaP(pila,&aux);
        CambiaSigno(pila);
        poneP(pila,(aux * (-1)));
    }
}

void MuestraPila(TPila *pila)
{
    TElementoP aux;
    if (!vaciaP(*pila))
    {
        sacaP(pila,&aux);
        MuestraPila(pila);
        printf("%d\n",aux);
        poneP(pila,aux);
    }
}
