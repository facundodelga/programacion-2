typedef char TElementoP;

typedef struct nodo2{
TElementoP dato;
struct nodo *sig;
} NodoP;

typedef NodoP* TPila;

void iniciaP(TPila *p);

void poneP(TPila *p, TElementoP x);

void sacaP(TPila *p, TElementoP *x);

TElementoP consultaP(TPila p);

int vaciaP(TPila p);
