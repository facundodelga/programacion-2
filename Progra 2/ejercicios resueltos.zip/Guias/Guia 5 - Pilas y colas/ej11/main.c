#include <stdlib.h>
#include <stdio.h>
#include "colaChar.h"
#include "pilaChar.h"

void Expresion(TCola* co, TPila* pn, float* rta);

int main(){
    TCola co;
    TPila pn;
    char elem;
    int esNum, esOp, contNum=0, contOp=0;
    float rta;
    iniciaC(&co);
    iniciaP(&pn);
    scanf(" %c", &elem);
    esNum = ((elem <= '9') && (elem >= '0'));
    esOp = ((elem == '+') || (elem == '-') || (elem == '*') || (elem == '/'));
    while ((esNum || esOp))
    {
        if (esNum)
        {
            poneP(&pn,elem);
            contNum++;
        }
        else
        {
            poneC(&co,elem);
            contOp++;
        }
        scanf(" %c", &elem);
        esNum = ((elem <= '9') && (elem >= '0'));
        esOp = ((elem == '+') || (elem == '-') || (elem == '*') || (elem == '/'));
    }
    if (contNum == (contOp + 1))
    {
        Expresion(&co,&pn,&rta);
        printf("El resultado de la expresi�n ingresada es: %3.2f",rta);
    }
    else
        printf("La expresi�n ingresada no es v�lida.");
    return 0;
}

void Expresion(TCola* co, TPila* pn, float* rta)
{
    char a, o;
    sacaP(pn,&a);
    a -= '0';
    *rta = a;
    while (!vaciaP(*pn))
    {
        sacaP(pn,&a);
        a -= '0';
        sacaC(co,&o);
        switch (o)
        {
        case '+':
            *rta=(*rta)+a;
            break;
        case '-':
            *rta=a-(*rta);
            break;
        case '*':
            *rta=(*rta)*a;
            break;
        case '/':
            if (a!=0)
                *rta=(*rta)/a;
            else
                *rta=0;
            break;
        }
    }
}
