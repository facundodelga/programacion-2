#include <stdio.h>
#include "colaInt.h"

void leerCola(TCola *c);

int main(void) {
    TCola cola;
    TElementoC n, suma;
    iniciaC(&cola);
    leerCola(&cola);
    suma = 0;
    while(!vaciaC(cola))
    {
        sacaC(&cola, &n);
        suma += n;
    }
    printf("%d", suma);
    return 0;
}

void leerCola(TCola *c)
{
    TElementoC n;
    while(scanf("%d", &n))
        poneC(c, n);
}
