#include "colaIntEstatica.h"
#include <stdlib.h>

void iniciaC(TCola *c)
{
    c->pri = c->ult = -1;
}

void poneC(TCola *c, TElementoC x)
{
    if (vaciaC(*c))
        c->pri = 0;
    if  (c->ult < 99)
        c->datos[++(c->ult)] = x;
}

void sacaC(TCola *c, TElementoC *x)
{
    if (!(vaciaC(*c)))
    {
        *x = c->datos[c->pri];
        if (c->pri == c->ult)
            iniciaC(c);
        else
            c->pri++;
    }
}

TElementoC consultaC(TCola c)
{
    if (!(vaciaC(c)))
        return c.datos[c.pri];
}

int vaciaC(TCola c)
{
    return (c.pri == -1);
}
