typedef int TElementoC;

typedef struct {
TElementoC datos[100];
int pri;
int ult;
} TCola;

void iniciaC(TCola *c);

void poneC(TCola *c, TElementoC x);

void sacaC(TCola *c, TElementoC *x);

TElementoC consultaC(TCola c);

int vaciaC(TCola c);
