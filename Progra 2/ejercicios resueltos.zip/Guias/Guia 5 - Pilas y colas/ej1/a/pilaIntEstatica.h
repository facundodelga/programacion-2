typedef int TElementoP;

typedef struct {
TElementoP datos[100];
int tope;
} TPila;

void iniciaP(TPila *p);

void poneP(TPila *p, TElementoP x);

void sacaP(TPila *p, TElementoP *x);

TElementoP consultaP(TPila p);

int vaciaP(TPila p);
