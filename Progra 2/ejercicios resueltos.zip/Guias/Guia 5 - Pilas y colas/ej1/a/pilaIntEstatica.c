#include "pilaIntEstatica.h"

void iniciaP(TPila *p)
{
    p->tope = -1;
}

void poneP(TPila *p, TElementoP x)
{
    p->datos[++(p->tope)] = x;
}

void sacaP(TPila *p, TElementoP *x)
{
    if (!vaciaP(*p))
        *x = p->datos[(p->tope)--];
}

TElementoP consultaP(TPila p)
{
    if (!vaciaP(p))
        return p.datos[p.tope];
}

int vaciaP(TPila p)
{
    return(p.tope == -1);
}
