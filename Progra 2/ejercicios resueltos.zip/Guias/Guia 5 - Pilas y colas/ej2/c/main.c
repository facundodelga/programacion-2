#include <stdio.h>
#include <stdlib.h>
#include "pilaChar.h"

void MuestraPila(TPila *pila);

int main()
{
    TElementoP letra;
    TPila pila;
    FILE *Arch;
    Arch = fopen("ej2.txt","rt");
    if (Arch != NULL)
    {
        iniciaP(&pila);
        while ((fscanf(Arch,"%c\n",&letra)) == 1)
            poneP(&pila,letra);
        MuestraPila(&pila);
    }
    else
        printf("No se encontr� el archivo ej2.txt\n");
	fclose(Arch);
    return 0;
}

void MuestraPila(TPila *pila)
{
    TElementoP aux;
    if (!(vaciaP(*pila)))
    {
        sacaP(pila,&aux);
        MuestraPila(pila);
        printf("%c",aux);
        poneP(pila,aux);
    }
}
