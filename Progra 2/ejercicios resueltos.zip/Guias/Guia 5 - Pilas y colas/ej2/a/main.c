#include <stdio.h>
#include <stdlib.h>
#include "pilaCharEstatica.h"

int main()
{
    TElementoP letra;
    TPila pila;
    FILE *Arch;
    Arch = fopen("ej2.txt","rt");
    if (Arch != NULL)
    {
        iniciaP(&pila);
        while ((fscanf(Arch,"%c\n",&letra)) == 1)
            poneP(&pila,letra);
        while (!(vaciaP(pila)))
        {
            sacaP(&pila,&letra);
            printf("%c",letra);
        }
    }
    else
        printf("No se encontr� el archivo ej2.txt\n");
	fclose(Arch);
    return 0;
}
