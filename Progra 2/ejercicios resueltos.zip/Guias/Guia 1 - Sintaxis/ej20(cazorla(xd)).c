#include<stdio.h>
#include<conio.h>

void binario(int x);
int main(){
  int x;
 printf("Ingrese un numero\n");
 scanf("%d",&x);
 binario(x);
 return 0;
}
void binario(int x){
  int resto;
   if (x>=0)
     printf("0");
   else{
     printf("1");
    x*=-1;
   }
   do{
      resto= (x%2);
      printf("%d", resto);
      x=(x/2);
   }while(x!=1);
}
