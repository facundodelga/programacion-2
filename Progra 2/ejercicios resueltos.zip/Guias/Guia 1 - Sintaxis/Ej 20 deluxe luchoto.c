#include <stdio.h>
#include <stdlib.h>
#define T 100
int main()
{
    int i=0,j,a,V[T];
    printf("Ingrese valor decimal a convertir: \n");
    scanf("%u",&a);
    if (a<0)
    {
        printf("1");
        a*=-1;
    }
    else
        printf("0");
    while (a>0)
    {
        V[i++]=a%2;
        a/=2;
    }
    for (j=i-1;j>=0;j--)
    {
        printf("%u",V[j]);
    }

    return 0;
}
