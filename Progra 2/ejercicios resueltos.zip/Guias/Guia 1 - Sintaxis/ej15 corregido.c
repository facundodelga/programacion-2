#include <stdio.h>
#include <stdlib.h>
int Consecutivos(int a, int b, int c);
int main()
{
    int a,b,c;
    printf("Ingresar 3 n�meros enteros.\n");
    scanf("%d %d %d",&a,&b,&c);
    if (Consecutivos(a,b,c))
        printf("Los n�meros ingresados son consecutivos.");
    else
        printf("Los n�meros ingresados no son consecutivos.");
    return 0;
}
int Consecutivos(int a, int b, int c)
{
    if ((c == b+1) && (b == a+1))
        return 1;
    else
        return 0;
}
