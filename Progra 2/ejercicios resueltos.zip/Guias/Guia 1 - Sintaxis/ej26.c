#include <stdio.h>
#include <stdlib.h>

typedef struct {
    char nombre[20];
    char apellido[20];
    char nacionalidad[20];
    unsigned int puntaje;
    } reg;

void GeneraDat();

void MostrarJugador(unsigned int Pos);

int main()
{
    unsigned int Pos;
    GeneraDat();
    printf("Ingrese la posici�n en el ranking del jugador a mostrar.\n");
    scanf("%u",&Pos);
    MostrarJugador(Pos);
    return 0;
}

void GeneraDat()
{
    reg Tenistas[100];
    unsigned int N = 0;
    FILE * ArchEsc;
    FILE * ArchLec;
    ArchLec = fopen("ej26a.txt","rt");
    ArchEsc = fopen("ej26b.dat", "wb");
    if (ArchLec == NULL)
       printf("No se encontr� el archivo ej26a.txt");
    else
    {
       while (!feof(ArchLec))
       {
          fscanf(ArchLec,"%s %s %s %u",&Tenistas[N].nombre,&Tenistas[N].apellido,&Tenistas[N].nacionalidad,&Tenistas[N].puntaje);
          N++;
       }
       fwrite(Tenistas,sizeof(reg),N,ArchEsc);
    }
    fclose(ArchLec);
    fclose(ArchEsc);
}

void MostrarJugador(unsigned int Pos)
{
    FILE * Arch;
    reg Tenista;
    Arch = fopen("ej26b.dat","rb");
    if (Arch == NULL)
        printf("No se encontr� el archivo ej26b.dat");
    else
    {
        fseek(Arch,((Pos-1)*(sizeof(reg))),0);
        fread(&Tenista,sizeof(reg),1,Arch);
        printf("El tenista en la posici�n %u es:\n %s %s de %s con %u puntos",Pos,Tenista.nombre,Tenista.apellido,Tenista.nacionalidad,Tenista.puntaje);
    }
    fclose(Arch);
}
