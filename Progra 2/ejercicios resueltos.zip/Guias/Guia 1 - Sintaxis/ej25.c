#include <stdio.h>
#include <stdlib.h>

typedef struct {
    char patente[7];
    unsigned int vel,velMax;
    char fecha[11];
    char hora[6];
    } reg;

int main()
{
    FILE * ArchLec;
    FILE * ArchEsc;
    reg Reg;
    unsigned int CantLec = 0, CantEsc = 0;
    ArchLec = fopen("ej25a.txt","rt");
    ArchEsc = fopen("ej25b.dat", "wb");
    if (ArchLec == NULL)
       printf("No se encontr� el archivo ej25a.txt");
    else
    {
        fscanf(ArchLec,"%6s %u %u %10s %5s",Reg.patente,&Reg.vel,&Reg.velMax,Reg.fecha,Reg.hora);
        while (!feof(ArchLec))
        {
           CantLec++;
           if (Reg.vel > (Reg.velMax * 1.2))
           {
               CantEsc++;
               fwrite(&Reg,sizeof(Reg),1,ArchEsc);
           }
           fscanf(ArchLec,"%6s %u %u %10s %5s",Reg.patente,&Reg.vel,&Reg.velMax,Reg.fecha,Reg.hora);
        }
        printf("Se procesaron %u datos y se encontraron %u infracciones.", CantLec,CantEsc);
    }
    fclose(ArchLec);
    fclose(ArchEsc);
    return 0;
}
