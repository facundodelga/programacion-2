#include <stdio.h>
#include <stdlib.h>

int main()
{
    unsigned int N , Suma = 0;
    printf("Ingrese los n�meros naturales a sumar.\n");
    do
    {
        scanf("%u", &N);
        Suma += N;
    } while (N != 0);
    printf("La suma de los n�meros ingresados es %u", Suma);
    return 0;
}
