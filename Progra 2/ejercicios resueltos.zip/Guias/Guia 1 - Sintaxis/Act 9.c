#include <stdio.h>
#include <stdlib.h>

int main()
{
    int x,y;
    printf("Ingrese valor de x\n");
    scanf("%d",&x);
    switch(x){
        case 4: y=7;
        break;
        case 5: y=9;
        break;
        case 9: y=14;
        break;
        default:y=22;
    }
    printf("El valor de y es %d",y);
    return 0;
}
