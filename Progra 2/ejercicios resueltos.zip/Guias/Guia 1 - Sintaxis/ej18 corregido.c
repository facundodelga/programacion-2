#include <stdio.h>
#include <stdlib.h>

int DuplicaParesFor(int v[], int N);

int DuplicaParesWhile(int v[], int N);

int DuplicaParesDoWhile(int v[], int N);

int main()
{
    int v[] = {8,4,5,37,99,85,77,1}, N = 8, i;
    DuplicaParesFor(v, N);
    printf("For:\n");
    for (i = 0; i < N; i++)
        printf("  %d", v[i]);
    printf("\n*****\n");
    DuplicaParesWhile(v, N);
    printf("While:\n");
    for (i = 0; i < N; i++)
        printf("  %d", v[i]);
    printf("\n*****\n");
    DuplicaParesDoWhile(v, N);
    printf("Do While:\n");
    for (i = 0; i < N; i++)
        printf("  %d", v[i]);
    return 0;
}

int DuplicaParesFor(int v[], int N)
{
    int i;
    for (i = 1; i < N; i += 2)
        v[i] *= 2;
    return 0;
}

int DuplicaParesWhile(int v[], int N)
{
    int i = 1;
    while (i < N)
    {
        v[i] *= 2;
        i += 2;
    }
    return 0;
}

int DuplicaParesDoWhile(int v[], int N)
{
    int i = 1;
    do
    {
        v[i] *= 2;
        i += 2;
    } while (i < N);
    return 0;
}
