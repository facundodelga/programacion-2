#include <stdio.h>
#include <stdlib.h>

int main()
{
    FILE * Arch;
    unsigned int N , Suma = 0;
    Arch = fopen("ej23.txt", "rt");
    if (Arch == NULL)
        printf("No se encontr� un archivo.");
    else
    {
       fscanf(Arch, "%u", &N);
       while ((!feof(Arch)) && (N!=0))
       {
           Suma += N;
           fscanf(Arch, "%u", &N);
       }
       printf("La suma de los n�meros presentes en el archivo es %u", Suma);
    }
    return 0;
}
