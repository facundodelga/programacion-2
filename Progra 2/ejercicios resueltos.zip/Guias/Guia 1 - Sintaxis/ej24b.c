#include <stdio.h>
#include <stdlib.h>

int main()
{
    FILE * Arch;
    float N, Max, Min, Prom = 0;
    int Cant = 0;
    Arch = fopen("ej24.dat", "rt");
    if (Arch == NULL)
        printf("El archivo ej24.dat no existe.");
    else
    {
        fread(&N, sizeof(N), 1, Arch);
        Max = Min = N;
        while (!feof(Arch))
        {
            Cant++;
            Prom += N;
            if (N < Min)
                Min = N;
            else
                if (N > Max)
                   Max = N;
            fread(&N, sizeof(N), 1, Arch);
        }
        Prom /= Cant;
        printf("La temperatura m�nima fue %4.2f.\n", Min);
        printf("La temperatura m�xima fue %4.2f.\n", Max);
        printf("El promedio de temperatura fue %4.2f.\n", Prom);
    }
    fclose(Arch);
    return 0;
}
