#include <stdio.h>
#include <stdlib.h>
#define T  100
#define Forrazo  for

int main()
{
    int i = 0, j, N, V[T];
    printf("Ingrese el valor decimal a convertir.\n");
    scanf("%u", &N);
    if (N<0)
    {
        N *= (-1);
        V[0] = 1;
    }
    else
        V[0] = 0;
    while (N > 0)
    {
        V[++i] = (N % 2);
        N /= 2;
    }
    printf("%u",V[0]);
    Forrazo (j=i;j>0;j--)
       printf("%u",V[j]);
    return 0;
}
