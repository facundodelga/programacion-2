#include <stdio.h>
#include <stdlib.h>
int HoraMinSeg(unsigned int SegTotal, unsigned int *Seg, unsigned int *Min, unsigned int *Horas);
int main()
{
    unsigned int SegTotal, Seg, Min, Horas;
    printf("Ingrese los segundos totales.\n");
    scanf("%u", &SegTotal);
    HoraMinSeg(SegTotal,&Seg,&Min,&Horas);
    printf("%02u:%02u:%02u",Horas,Min,Seg);
    return 0;
}
int HoraMinSeg(unsigned int SegTotal, unsigned int *Seg, unsigned int *Min, unsigned int *Horas)
{
    *Horas = SegTotal / 3600;
    *Min = (SegTotal - (*Horas * 3600)) / 60;
    *Seg = SegTotal - *Horas * 3600 - *Min * 60;
    return 0;
}
