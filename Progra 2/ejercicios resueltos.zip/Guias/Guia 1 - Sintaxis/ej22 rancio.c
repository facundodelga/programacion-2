#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{
    char cad1[20], cad2[20], cad3[20];
    printf("Cad1:\n");
    gets(cad1);
    printf("Cad2:\n");
    gets(cad2);
    if (strcmp(cad1,cad2))
    {
        strcpy(cad3,cad1);
        printf("Cad3:\n");
    }
    else
        strcpy(cad3,"Cad1 y Cad2 son iguales");
    printf("%s",cad3);
}
