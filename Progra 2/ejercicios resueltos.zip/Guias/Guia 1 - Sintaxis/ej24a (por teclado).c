#include <stdio.h>
#include <stdlib.h>

int main()
{
    FILE * Arch;
    float N;
    Arch = fopen("ej24.dat", "wt");
    printf("Ingresar un n�mero real.\n");
    scanf("%f", &N);
    while (N!=0)
    {
        fwrite(&N,sizeof(N),1,Arch);
        printf("Ingresar un n�mero real.\n");
        scanf("%f", &N);
    }
    fclose(Arch);
    return 0;
}
