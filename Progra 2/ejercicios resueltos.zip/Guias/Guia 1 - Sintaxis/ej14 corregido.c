#include <stdio.h>
#include <stdlib.h>
int DibujarCuadrado(int N);
int main()
{
    unsigned int N;
    printf("Ingrese el lado del cuadrado.\n");
    scanf("%u", &N);
    DibujarCuadrado(N);
    return 0;
}
int DibujarCuadrado(int N)
{
    unsigned int i, j;
    for (i = 1; i <= N; i++)
        printf("#");
    printf("\n");
    for (i = 2; i < N; i++)
    {
        printf("#");
        for (j = 2; j < N; j++)
            printf(" ");
        printf("#\n");
    }
    for (i = 1; i <= N; i++)
        printf("#");
}
