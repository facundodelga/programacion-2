#include <stdio.h>
#include <stdlib.h>

int main()
{
   //Punto A//
   int a,b,c;
   a=2;
   b=3;
   c=a<b?a:b;
   printf("Valor de c es %d\n",c);
   c=4;
   //Punto B//
   printf((a<b && b<c)?"ordenados":"desordenados");
   return 0;
}
