#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define N 10
int main()
{
    int suma=0,k;
    FILE *Arch;
    Arch=fopen("Act23.txt","rt");
    if (Arch==NULL)
        printf("no abri�");
    else
    {
        fscanf(Arch,"%d",&k);
        while(!feof(Arch) & k!=0){
            suma+=k;
            fscanf(Arch,"%d",&k);
        }
        fclose(Arch);
        printf("termine\n");
        printf("%d",suma);
    }
    return 0;
}
