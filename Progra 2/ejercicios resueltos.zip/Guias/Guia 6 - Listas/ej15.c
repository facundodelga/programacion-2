#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#define N 5
typedef struct nodoD{
    int num;
    struct nodoD *ant,*sig;
}NodoD;

typedef NodoD *PNodoD;

typedef struct{
    PNodoD pri,ult;
}TListaD;

void GeneraListaD(TListaD *LD,int V[N]);

void MuestraListaD(TListaD LD);

void Inserta(TListaD *LD,int x);

void Elimina(TListaD *LD,int pos);

int main(){
    TListaD LD;
    LD.pri=NULL;
    LD.ult=NULL;
    int V[N]={1,2,3,4,5},pos=1;
    GeneraListaD(&LD,V);
    //MuestraListaD(LD);
    //Inserta(&LD,3);
    printf("\n\n\n");
    //MuestraListaD(LD);
    Elimina(&LD,pos);
    MuestraListaD(LD);
    return 0;
}

void GeneraListaD(TListaD *LD,int V[N])
{
    PNodoD aux;
    int i;
    for (i=0;i<N;i++)
    {
        aux=(PNodoD)malloc(sizeof(NodoD));
        aux->num=V[i];
        aux->ant=aux->sig=NULL;
        if (LD->pri==NULL)
            LD->pri=LD->ult=aux;
        else
        {
            LD->ult->sig=aux;
            aux->ant=LD->ult;
            LD->ult=aux;
        }
    }
}

void MuestraListaD(TListaD LD)
{
    PNodoD aux=LD.pri;
    while (aux!=NULL)
    {
        printf("%d \t",aux->num);
        aux=aux->sig;
    }
}

void Inserta(TListaD *LD,int x)
{
    PNodoD act=LD->pri,aux;
    int cont=1,i;
    aux=(PNodoD)malloc(sizeof(NodoD));
    aux->num=x;
    aux->ant=aux->sig=NULL;
    if (act!=NULL)
    {
        while (act->sig!=NULL)
        {
            cont++;
            act=act->sig;
        }
        if (cont==1)
        {
            LD->ult=aux;
            LD->pri->sig=aux;
            aux->ant=LD->pri;
        }
        else
        {
            for (i=0;i<((cont/2));i++)
                act=act->ant;
            aux->sig=act->sig;
            aux->ant=act;
            act->sig->ant=aux;
            act->sig=aux;
        }
    }
    else
        LD->pri=LD->ult=aux;
}

void Elimina(TListaD *LD,int pos)
{
    int i;
    PNodoD act=LD->pri,aux;
    if (act!=NULL)
    {
        if (pos==0)
        {
            free(act);
            LD->pri=LD->ult=NULL;
        }
        else
        {
            for (i=1;i<pos;i++)
                act=act->sig;
            if (act!=LD->ult)
                if (act->sig==LD->ult)
                {
                    LD->ult=act;
                    free(act->sig);
                    act->sig=NULL;
                }
                else
                {
                    aux=act->sig;
                    act->sig=aux->sig;
                    aux->sig->ant=act;
                    free(aux);
                }
        }
    }
}
