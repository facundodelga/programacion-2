#include <stdlib.h>
#include <stdio.h>
#include "ColaD.h"

void IniciaC(TCola *cola)
{
    (cola->pri)=(cola->ult)=NULL;
}

void PoneC(TCola *cola,TElementoC x)
{
    if (VaciaC(*cola))
    {
        cola->pri=cola->ult=(NodoC*)malloc(sizeof(NodoC));
        cola->pri->sig=NULL;
    }
    else
    {
        cola->ult->sig=(NodoC*)malloc(sizeof(NodoC));
        cola->ult=cola->ult->sig;
        cola->ult->sig=NULL;
    }
    cola->ult->dato=x;
}

void SacaC(TCola *cola,TElementoC *x)
{
    NodoC *aux;
    if (!VaciaC(*cola)){
        aux=cola->pri;
        *x=aux->dato;
        cola->pri=cola->pri->sig;
        free(aux);
    }
}

TElementoC ConsultaC(TCola cola)
{
    if (VaciaC(cola))
        return (cola.pri)->dato;
}

int VaciaC(TCola cola)
{
    return (cola.pri==NULL);
}
