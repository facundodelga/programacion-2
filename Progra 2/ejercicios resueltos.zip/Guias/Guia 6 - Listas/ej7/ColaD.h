typedef int TElementoC;

typedef struct nodo2{
    TElementoC dato;
    struct nodo2 *sig;
}NodoC;

typedef struct{
    NodoC *pri,*ult;
}TCola;

void IniciaC(TCola *cola);

void PoneC(TCola *cola,TElementoC x);

void SacaC(TCola *cola,TElementoC *x);

TElementoC ConsultaC(TCola cola);

int VaciaC(TCola cola);

