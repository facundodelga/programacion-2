#include <stdlib.h>
#include <stdio.h>
#include "PilaD.h"
#include "ColaD.h"

typedef struct nodo{
    TCola dato;
    struct nodo *sig;
}NodoL;
typedef NodoL* TLista;

void CargaLista(TLista *lista);

void GeneraPila(TLista lista,TPila *pila);

void BuscaMax(TCola *cola,int *max);

void MuestraPila(TPila *pila);


int main(){
    TLista lista=NULL;
    TPila pila;
    IniciaP(&pila);
    CargaLista(&lista);
    GeneraPila(lista,&pila);
    MuestraPila(&pila);
    return 0;
}

void CargaLista(TLista *lista)
{
    int i,CantList=3,elem;
    char basura;
    TLista aux,act;
    TCola cola;
    for (i=1;i<CantList;i++)
    {
        aux=(TLista)malloc(sizeof(NodoL));
        IniciaC(&cola);
        printf("lista %d \n",i);
        while (scanf(" %d",&elem)==1)
            PoneC(&cola,elem);
        scanf("%c",&basura);
        aux->dato=cola;
        aux->sig=NULL;
        if (*lista==NULL)
            *lista=aux;
        else
        {
            act=*lista;
            while (act->sig!=NULL)
                act=act->sig;
            act->sig=aux;
        }
    }
}

void GeneraPila(TLista lista,TPila *pila)
{
    int max;
    TCola cola;
    while (lista!=NULL)
    {
        cola=lista->dato;
        BuscaMax(&cola,&max);
        PoneP(pila,max);
        lista=(lista)->sig;
    }
}
void BuscaMax(TCola *cola,int *max)
{
    TElementoC elem;
    if (!VaciaC(*cola))
    {
        SacaC(cola,&elem);
        BuscaMax(cola,max);
        if (elem>*max)
            *max=elem;
    }
    else
        *max=-9999;
}

void MuestraPila(TPila *pila)
{
    TElementoP elem;
    if (!VaciaP(*pila))
    {
        SacaP(pila,&elem);
        MuestraPila(pila);
        printf("%d \t",elem);
        PoneP(pila,elem);
    }
}
