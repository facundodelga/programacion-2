typedef int TElementoP;

typedef struct nodo1{
    TElementoP dato;
    struct nodo1 *sig;
}NodoP;

typedef NodoP* TPila;

void IniciaP(TPila *pila);

void PoneP(TPila *pila,TElementoP x);

void SacaP(TPila *pila,TElementoP *x);

TElementoP ConsultaP(TPila pila);

int VaciaP(TPila pila);
