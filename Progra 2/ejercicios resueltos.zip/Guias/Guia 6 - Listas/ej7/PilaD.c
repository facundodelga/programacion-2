#include <stdlib.h>
#include <stdio.h>
#include "PilaD.h"

void IniciaP(TPila *pila)
{
    *pila=NULL;
}

void PoneP(TPila *pila,TElementoP x)
{
    TPila N;
    N=(TPila)malloc(sizeof(NodoP));
    N->dato=x;
    N->sig=*pila;
    *pila=N;
}

void SacaP(TPila *pila,TElementoP *x)
{
    TPila aux;
    if (!VaciaP(*pila))
    {
        aux=*pila;
        *x=aux->dato;
        *pila=(*pila)->sig;
        free(aux);
    }
}
TElementoP ConsultaP(TPila pila)
{
    if (!VaciaP(pila))
        return pila->dato;
}
int VaciaP(TPila pila)
{
    return (pila==NULL);
}
