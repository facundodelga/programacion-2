#include <stdio.h>
#include <stdlib.h>
#include "ColaInt.h"
#include "PilaInt.h"

typedef struct nodol{
TCola datos;
struct nodol *sig}nodol;

typedef nodol *TLista;

void CargarLista(TLista *lista);

void GenerarPila(TLista lista,TPila *pila);

void MostrarPila(TPila *pila);

int main()
{
    TLista lista;
    TPila pila;
    CargarLista(&lista);
    GenerarPila(lista,&pila);
    printf("La pila con maximos sera:\n");
    MostrarPila(&pila);
    return 0;
}

void CargarLista(TLista *lista)
{
    int i,j,x;
    TCola cola;
    TLista aux,act;
    *lista=NULL;
    for (i=0;i<5;i++)
    {
        aux=(TLista)malloc(sizeof(nodol));
        IniciaC(&cola);
        for(j=0;j<3;j++)
        {
            scanf("%d",&x);
            poneC(&cola,x);
        }
        aux->datos=cola;
        aux->sig=NULL;
        act=*lista;
        if (*lista == NULL)
            *lista=aux;
        else
        {
            while (act->sig!=NULL)
                act=act->sig;
            act->sig=aux;
        }
        printf("*****\n");
    }
}

void GenerarPila(TLista lista,TPila *pila)
{
    IniciaP(pila);
    TElementoC x,maximo;
    while(lista!=NULL)
    {
        maximo=0;
        while(!VaciaC(lista->datos))
        {
            sacaC(&(lista->datos),&x);
            if (x>maximo)
                maximo=x;
        }
        poneP(pila,maximo);
        lista=lista->sig;
    }
}

void MostrarPila(TPila *pila)
{
    TElementoP x;
    if (!VaciaP(*pila))
    {
        sacaP(pila,&x);
        printf("%d ",x);
        MostrarPila(pila);
        poneP(pila,x);
    }

}
