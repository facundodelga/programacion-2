#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define N 4

typedef struct nodo{
int dato;
struct nodo* sig;
} NodoL;

typedef NodoL* TLista;

void cargarLista(TLista *lista);

void Muestra(TLista lista);

int main(){
    int i, v[N] = {4,8,9,60};
    TLista lista=NULL, act, ant, nuevo;
    cargarLista(&lista);
    printf("\nLista Original\n");
    Muestra(lista);
    act = lista;
    ant = NULL;
    for (i=0; i<N; i++)
    {
        while ((act != NULL) && (v[i] >= act->dato))
        {
            ant = act;
            act = act->sig;
        }
        nuevo = (TLista) malloc(sizeof(NodoL));
        nuevo->dato = v[i];
        if(ant == NULL)
        {
            nuevo->sig = act;
            lista = nuevo;
        }
        else
        {
            nuevo->sig = act;
            ant->sig = nuevo;
        }
        act = nuevo;
    }
    printf("\nLista Resultado\n");
    Muestra(lista);
    return 0;
}

void cargarLista(TLista *lista)
{
    TLista aux;
    int elem;
    while (scanf("%d", &elem))
    {
        aux = (TLista) malloc(sizeof(NodoL));
        aux->dato = elem;
        aux->sig = *lista;
        *lista = aux;
    }
}

void Muestra(TLista lista)
{
    while (lista != NULL)
    {
        printf(" %d", lista->dato);
        lista = lista->sig;
    }
}