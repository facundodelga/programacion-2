#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#define N 5

//LISTA CIRCULAR

typedef struct nodoC{
    int num;
    struct nodoC *sig;
}NodoC;

typedef NodoC *TListaC;

typedef struct nodo{
    int num;
    struct nodo *sig;
}NodoL;

typedef NodoL *TLista;

typedef struct nodoD{
    int num;
    struct nodoD *ant, *sig;
}NodoD;

typedef NodoD *PnodoD;

typedef struct{
    PnodoD pri,ult;
}TListaD;

void Generalista(TLista *listaS,int V[N]);

void MuestraLista(TLista listaS);

void MuestraListaC(TListaC listaC);

void MuestraListaD(TListaD listaD);

void Generalistas(TLista listaS,TListaC *LC,TListaD *LD);

int main(){
    TLista listaS=NULL;
    TListaD listaD;
    TListaC listaC=NULL;
    int V[N]={1,2,3,4,5};
    Generalista(&listaS,V);
    Generalistas(listaS,&listaC,&listaD);
    MuestraLista(listaS);
    printf("\n\n\n\n");
    MuestraListaC(listaC);
    printf("\n\n\n\n");
    MuestraListaD(listaD);
    return 0;
}

void Generalista(TLista *listaS,int V[N])
{
    TLista aux,ult;
    int i;
    for (i=0;i<N;i++)
    {
        aux=(TLista)malloc(sizeof(NodoL));
        aux->num=V[i];
        aux->sig=NULL;
        if (*listaS==NULL){
            *listaS=aux;
            ult=*listaS;
        }
        else
        {
            ult->sig=aux;
            ult=aux;
        }
    }
}

void MuestraLista(TLista listaS)
{
    while(listaS!=NULL)
    {
        printf("%d \t",listaS->num);
        listaS=listaS->sig;
    }
}

void MuestraListaC(TListaC listaC)
{
    TListaC aux=listaC;
    do
    {
        aux=aux->sig;
        printf("%d \t",aux->num);
    }
    while (aux!=listaC);
}

void MuestraListaD(TListaD listaD)
{
    PnodoD aux=listaD.pri;
    while (aux!=NULL)
    {
        printf("%d \t",aux->num);
        aux=aux->sig;
    }
}
void Generalistas(TLista listaS,TListaC *LC,TListaD *LD)
{
    (*LD).pri=NULL;
    (*LD).ult=NULL;
    *LC=NULL;
    TListaC auxc;
    PnodoD auxd;
    while (listaS!=NULL)
    {
        auxc=(TListaC)malloc(sizeof(NodoC));
        auxd=(PnodoD)malloc(sizeof(NodoD));
        auxc->num=auxd->num=listaS->num;
        auxd->ant=auxd->sig=NULL;
        if (LD->pri==NULL)
            LD->pri=LD->ult=auxd;
        else
        {
            LD->ult->sig=auxd;
            auxd->ant=LD->ult;
            LD->ult=auxd;
        }
        if (*LC==NULL)
        {
            *LC=auxc;
            auxc->sig=*LC;
        }
        else
        {
            auxc->sig=(*LC)->sig;
            (*LC)->sig=auxc;
            *LC=auxc;
        }
    listaS=listaS->sig;
    }
}
