#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct nodo{
int dato;
struct nodo* sig;
} NodoL;

typedef NodoL* TLista;

void cargarLista(TLista *lista);

void Muestra(TLista lista);

int Iguales(TLista lista1, TLista lista2);

void Agrega(TLista* lista1, TLista* lista2);

void EliminarL2enL1(TLista* lista1, TLista lista2);

int main(){
    char basura;
    TLista lista1 = NULL, lista2 = NULL;
    printf("Ingrese la lista 1.\n");
    cargarLista(&lista1);
    printf("\n*****\n");
    printf("Ingrese la lista 2.\n");
    scanf("%c",&basura);
    cargarLista(&lista2);
    printf("\n*****\n");
    if (Iguales(lista1,lista2))
        printf("Las listas ingresadas son iguales.\n");
    else
        printf("Las listas ingresadas no son iguales.\n");
    Agrega(&lista1,&lista2);
    printf("\n*****\n");
    printf("Lista 1:\n");
    Muestra(lista1);
    printf("\n*****\n");
    printf("Lista 2:\n");
    Muestra(lista2);
    EliminarL2enL1(&lista1,lista2);
    printf("\n*****\n");
    printf("Lista 1 con las posici�nes de L2 eliminadas:\n");
    Muestra(lista1);
    return 0;
}

void cargarLista(TLista *lista)
{
    TLista aux, ant;
    int elem;
    while (scanf(" %d", &elem) == 1)
    {
        aux = (TLista) malloc(sizeof(NodoL));
        aux->dato = elem;
        aux->sig = NULL;
        if (*lista == NULL)
            *lista = aux;
        else
        {
            ant = *lista;
            while (ant->sig != NULL)
                ant = ant->sig;
            ant->sig = aux;
        }
    }
}

void Muestra(TLista lista)
{
    while (lista != NULL)
    {
        printf(" %d", lista->dato);
        lista = lista->sig;
    }
}

int Iguales(TLista lista1, TLista lista2)
{
    int sonIguales = 1;
    while ((lista1 != NULL) && (lista2 != NULL) && sonIguales)
    {
        if (lista1->dato == lista2->dato)
        {
            lista1 = lista1->sig;
            lista2 = lista2->sig;
        }
        else
            sonIguales = 0;
    }
    return (!((lista1 != NULL) || (lista2 != NULL)) && sonIguales);
}

void Agrega(TLista* lista1, TLista* lista2)
{
    TLista act1 = *lista1, act2 = *lista2;
    if (act1 != NULL)
        while (act1->sig != NULL)
            act1 = act1->sig;
    if (act2 != NULL)
        while (act2->sig != NULL)
            act2 = act2->sig;
    else
        *lista2 = *lista1;
    if ((act1 != NULL) && (act2 != NULL))
        if (((*lista2)->dato) > (act1->dato))
            act1->sig = *lista2;
        else
            act2->sig = *lista1;
}

void EliminarL2enL1(TLista* lista1, TLista lista2)
{
    TLista ant = NULL, act = *lista1, liberar;
    int i = 1;
    while ((act != NULL) && (lista2 != NULL))
    {
        while ((act != NULL) && (i < lista2->dato))
        {
            i++;
            ant = act;
            act = act->sig;
        }
        if (act != NULL)
        {
            liberar = act;
            if (ant != NULL)
                act = ant->sig = act->sig;
            else
                act = *lista1 = act->sig;
            free(liberar);
        }
        i++;
        lista2 = lista2->sig;
    }
}
