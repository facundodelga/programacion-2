#include <stdio.h>
#include <stdlib.h>

typedef struct nodo{
int dato;
struct nodo* sig;
} NodoL;

typedef NodoL* TLista;

int main()
{
    int v[] = {1,2,3,4,5}, n = 5, i;
    TLista lista = NULL, aux;
    for (i=0;i<n;i++)
    {
        aux = (TLista) malloc(sizeof(NodoL));
        aux->dato = v[i];
        aux->sig = lista;
        lista = aux;
    }
    for (i=0;i<n;i++)
    {
        printf("%d ", aux->dato);
        aux = aux->sig;
    }
    return 0;
}
