#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#define N 100

//LISTA CIRCULAR

typedef struct nodoC{
    unsigned long int DNI;
    char sexo;
    struct nodoC *sig;
}NodoC;

typedef NodoC *TListaC;

void GeneraLista(TListaC *LC,int *contf,int *contm);

void MuestraLista(TListaC LC);

int Busca(TListaC LC,unsigned long int DNI);

int main(){
    int contf,contm;
    unsigned long int DNI=42455271;
    TListaC LC=NULL;
    GeneraLista(&LC,&contf,&contm);
    MuestraLista(LC);
    printf("%d %d",contf,contm);
    if (Busca(LC,DNI))
        printf("\nSe encontro");
    else
        printf("\nNo se encontro");
    return 0;
}
void GeneraLista(TListaC *LC,int *contf,int *contm)
{
    FILE *Arch;
    TListaC aux;
    unsigned long int DNI;
    char sexo;
    *contf=*contm=0;
    Arch=fopen("ej13.txt","rt");
    while (fscanf(Arch,"%lu %c",&DNI,&sexo)==2)
    {
        strupr(&sexo);
        if (sexo=='F')
        {
            *contf+=1;
            aux=(TListaC)malloc(sizeof(NodoC));
            aux->DNI=DNI;
            aux->sexo=sexo;
            if (*LC==NULL)
            {
                *LC=aux;
                aux->sig=*LC;
            }
            else
            {
                aux->sig=(*LC)->sig;
                (*LC)->sig=aux;
                *LC=aux;
            }
        }
        else
            *contm+=1;
    }
    fclose(Arch);
}

void MuestraLista(TListaC LC)
{
    TListaC aux=LC;
    do
    {
        aux=aux->sig;
        printf("%lu %c\n",aux->DNI,aux->sexo);
    }
    while (aux!=LC);
}
int Busca(TListaC LC,unsigned long int DNI)
{
    TListaC aux;
    int encontro=0;
    if (LC!=NULL)
    {
        aux=LC;
        do
        {
            aux=aux->sig;
            if (aux->DNI==DNI)
                encontro=1;
        }
        while (aux!=LC && encontro!=1);
    }
    return encontro;
}
