#include <stdio.h>
#include <stdlib.h>

typedef struct nodo{
int dato;
struct nodo* sig;
} NodoL;

typedef NodoL* TLista;

void InsertaOrd(TLista* lista, int num);

int main()
{
    int v[] = {2,1,4,5,3}, n = 5, i;
    TLista lista, aux;
    lista = NULL;
    for (i=0;i<n;i++)
        InsertaOrd(&lista, v[i]);
    aux = lista;
    for (i=0;i<n;i++)
    {
        printf("%d ", aux->dato);
        aux = aux->sig;
    }
    return 0;
}

void InsertaOrd(TLista* lista, int num)
{
    TLista aux, ant, act;
    aux = (TLista) malloc(sizeof(NodoL));
    aux->dato = num;
    if (*lista == NULL)
    {
        *lista = aux;
        aux->sig = NULL;
    }
    else
    {
        if (num <= (*lista)->dato)
        {
            aux->sig = (*lista);
            *lista = aux;
        }
        else
        {
            ant = *lista;
            act = ant->sig;
            while ((act != NULL) && (act->dato <= num))
            {
                ant = act;
                act = act->sig;
            }
            ant->sig = aux;
            aux->sig = act;
        }
    }
}
