#include <stdio.h>
#include <stdlib.h>

typedef struct nodo{
int dato;
struct nodo* sig;
} NodoL;

typedef NodoL* TLista;

int main()
{
    int v[] = {2,1,4,5,3}, n = 5, i;
    TLista lista, aux, act;
    lista = (TLista) malloc(sizeof(NodoL));
    lista->dato = v[0];
    lista->sig = NULL;
    act = lista;
    for (i=1;i<n;i++)
    {
        act = act->sig = (TLista) malloc(sizeof(NodoL));
        act->dato = v[i];
        act->sig = NULL;
    }
    aux = lista;
    for (i=0;i<n;i++)
    {
        printf("%d ", aux->dato);
        aux = aux->sig;
    }
    return 0;
}
