#include <stdlib.h>
#include <stdio.h>
typedef struct nodo{
    int n;
    struct nodo *sig;
}NodoL;
typedef NodoL* TLISTA;

void CargaLista(TLISTA* lista);

void Agrega(TLISTA *lista1,TLISTA *lista2);

void muestra(TLISTA lista);

void Elimina(TLISTA *lista1,TLISTA lista2);

int Iguales(TLISTA l1,TLISTA l2);

int main(){
    char basura;
    TLISTA l1=NULL,l2=NULL;
    CargaLista(&l1);
    scanf("%c",&basura);
    CargaLista(&l2);
    if (Iguales(l1,l2))
        printf("Son iguales");
    else
        printf("No son iguales");
    //Agrega(&l1,&l2);
    //printf("\n Lista 1\n");
    //muestra(l1);
    //printf("\n Lista 2\n");
    //muestra(l2);
    Elimina(&l1,l2);
    printf("\n Lista 1\n");
    muestra(l1);
    printf("\n Lista 2\n");
    muestra(l2);

    return 0;
}

void CargaLista(TLISTA* lista)
{
    TLISTA aux,ant;
    int dato;
    while ((scanf("%d",&dato)==1)){
        aux=(TLISTA)malloc(sizeof(NodoL));
        aux->n=dato;
        aux->sig=NULL;
        if (*lista==NULL)
            *lista=aux;
        else
        {
            ant=*lista;
            while ((ant->sig)!=NULL)
                ant=ant->sig;
            ant->sig=aux;
        }
    }
}
void muestra(TLISTA lista)
{
    while (lista!=NULL)
    {
        printf("%d\n",lista->n);
        lista=lista->sig;
    }
}

int Iguales(TLISTA l1,TLISTA l2)
{
    int soniguales=1;
    while (((l1!=NULL) && (l2!=NULL)) && (soniguales!=0))
    {
        if (l1->n == l2->n)
        {
            l1=l1->sig;
            l2=l2->sig;
        }
        else
            soniguales=0;
    }
    return (!((l1!=NULL) || (l2!=NULL)) &&soniguales);

}
void Agrega(TLISTA *lista1,TLISTA *lista2)
{
    TLISTA act1=*lista1,act2=*lista2;
    if (act1!=NULL)
        while (act1->sig!=NULL)
            act1=act1->sig;
    if (act2!=NULL)
        while (act2->sig!=NULL)
            act2=act2->sig;
    else
        *lista2=*lista1;
    if ((act1 !=NULL )&& (act2 !=NULL))
        if (((*lista2)->n)>(act1->n))
            act1->sig=*lista2;
        else
            act2->sig=*lista1;
}

void Elimina(TLISTA *lista1,TLISTA lista2)
{
    TLISTA act,ant;
    int pos,i=1;
    while (lista2!=NULL && *lista1!=NULL)
    {
        pos=lista2->n;
        lista2=lista2->sig;
        act=*lista1;
        ant=NULL;
        while (act!=NULL && i<(pos))
        {
            i++;
            ant=act;
            act=act->sig;
        }
        if (act!=NULL)
        {
            if (ant!=NULL)
                ant->sig=act->sig;
            else
            {
                *lista1=act->sig;
                i+=1;
            }
            free(act);
        }
    }
}
