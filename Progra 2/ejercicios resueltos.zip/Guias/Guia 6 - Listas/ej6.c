#include <stdio.h>
#include <stdlib.h>

typedef struct nodo{
int dato;
struct nodo* sig;
} NodoL;

typedef NodoL* TLista;

void CargarLista(TLista *lista);

void Mostrar(TLista lista);

void Separar(TLista orig, TLista* pares, TLista* impares);

int main(){
    TLista orig = NULL, pares = NULL, impares = NULL;
    printf("Ingrese la lista a separar.\n");
    cargarLista(&orig);
    printf("\n*****\n");
    printf("La lista original es:\n");
    Mostrar(orig);
    printf("\n(SE VA A PERDER)\n*****\n");
    Separar(orig,&pares,&impares);
    printf("Lista de pares ordenados ascendientemente:\n");
    Mostrar(pares);
    printf("\n*****\n");
    printf("Lista de impares ordenados descendientemente:\n");
    Mostrar(impares);
    printf("\n*****\n");
    return 0;
}

void cargarLista(TLista *lista)
{
    TLista aux, ant;
    int elem;
    while (scanf(" %d", &elem) == 1)
    {
        aux = (TLista) malloc(sizeof(NodoL));
        aux->dato = elem;
        aux->sig = NULL;
        if (*lista == NULL)
            *lista = aux;
        else
        {
            ant = *lista;
            while (ant->sig != NULL)
                ant = ant->sig;
            ant->sig = aux;
        }
    }
}

void Mostrar(TLista lista)
{
    while (lista != NULL)
    {
        printf(" %d", lista->dato);
        lista = lista->sig;
    }
}

void Separar(TLista orig, TLista* pares, TLista* impares)
{
    TLista aux, paresAct = *pares;
    while (orig != NULL)
    {
        aux = orig->sig;
        if ((orig->dato % 2) == 0)
        {
            orig->sig = NULL;
            if (*pares != NULL)
                paresAct = paresAct->sig = orig;
            else
                paresAct = *pares = orig;
        }
        else
        {
            orig->sig = *impares;
            *impares = orig;
        }
        orig = aux;
    }
}
