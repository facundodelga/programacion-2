#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#define N 50

typedef struct nodoD{
    char Apellido[N],Nombre[N],Categoria;
    struct nodoD *ant,*sig;
}NodoD;
typedef struct nodoD *PNodoD;

typedef struct{
    PNodoD pri,ult;
}TListaD;

void CargaLista(TListaD *LD);

void OrdenaLista(TListaD LD,TListaD *lista,int x,int *imptotal);

void MuestraLista(TListaD lista);

void GeneraExt(TListaD lista,TListaD *externos);

int BuscaApellido(TListaD listaord,char X[N]);

int main(){
    TListaD LD,listaord,externos;
    char Apellido[]="Casamayou";
    int x=101,imptotal;
    listaord.pri=NULL;
    listaord.ult=NULL;
    externos.pri=NULL;
    externos.ult=NULL;
    LD.pri=NULL;
    LD.ult=NULL;
    CargaLista(&LD);
    MuestraLista(LD);
    printf("\n\n\n\n");
    OrdenaLista(LD,&listaord,x,&imptotal);
    MuestraLista(listaord);
    printf("\nEl importe total es: %d ",imptotal);
    GeneraExt(listaord,&externos);
    MuestraLista(externos);
    if (BuscaApellido(listaord,Apellido))
        printf("\nEncontro apellido");
    else
        printf("No encontro forrazo");
    return 0;
}
void CargaLista(TListaD *LD)
{
    int i;
    char Apellido[N],Nombre[N],Categoria;
    PNodoD aux;
    for (i=1;i<5;i++)
    {
        scanf("%s",Apellido);
        scanf("\n%s",Nombre);
        scanf(" %c",&Categoria);
        aux=(PNodoD)malloc(sizeof(NodoD));
        strcpy(aux->Apellido,Apellido);
        strcpy(aux->Nombre,Nombre);
        aux->Categoria=Categoria;
        aux->sig=NULL;
        if (LD->pri==NULL)
        {
            aux->ant=NULL;
            LD->pri=aux;
            LD->ult=aux;
        }
        else
        {
            LD->ult->sig=aux;
            aux->ant=LD->ult;
            LD->ult=aux;
        }
    }
}

void OrdenaLista(TListaD LD,TListaD *lista,int x,int *imptotal)
{
    PNodoD act,aux,aux2;
    if (LD.pri!=NULL)
    {
        act=LD.pri;
        *imptotal=0;
        while (act!=NULL)
        {
            aux=(PNodoD)malloc(sizeof(NodoD));
            strcpy(aux->Apellido,act->Apellido);
            strcpy(aux->Nombre,act->Nombre);
            aux->Categoria=act->Categoria;
            aux->sig=NULL;
            aux->ant=NULL;
            if (aux->Categoria!='e')
            {
                if (aux->Categoria=='d')
                    *imptotal+=(x*0.7);
                else
                    *imptotal+=(x*0.9);
            }
            else
                (*imptotal)+=x;
            if (lista->pri==NULL)
            {
                lista->pri=aux;
                lista->ult=aux;
            }
            else
            {
                if (strcmp(aux->Apellido,lista->pri->Apellido)<1)//Si apellido del actual es menor o igual al apellido de la lista, entra al if
                {
                    lista->pri->ant=aux;
                    aux->sig=lista->pri;
                    aux->ant=NULL;
                    lista->pri=aux;
                }
                else
                {
                    if (strcmp(aux->Apellido,lista->ult->Apellido)>-1)
                    {
                        lista->ult->sig=aux;
                        aux->ant=lista->ult;
                        aux->sig=NULL;
                        lista->ult=aux;
                    }
                    else
                    {
                        aux2=lista->pri->sig;
                        while (strcmp(aux->Apellido,aux2->Apellido)>-1)
                            aux2=aux2->sig;
                        aux->sig=aux2;
                        aux2->ant->sig=aux;
                        aux->ant=aux2->ant;
                        aux2->ant=aux;
                    }
                }
            }
        act=act->sig;
        }
    }
}

void MuestraLista(TListaD lista)
{
    PNodoD aux=lista.pri;
    while (aux!=NULL)
    {
        printf("\nApellido: %s",aux->Apellido);
        aux=aux->sig;
    }
}

void GeneraExt(TListaD lista,TListaD *externos)
{
    PNodoD aux;
    TListaD act=lista;
    while (act.pri!=NULL)
    {
        if (act.pri->Categoria=='e')
        {
            aux=(PNodoD)malloc(sizeof(NodoD));
            strcpy(aux->Apellido,act.pri->Apellido);
            strcpy(aux->Nombre,act.pri->Nombre);
            aux->Categoria=act.pri->Categoria;
            aux->sig=NULL;
            aux->ant=NULL;
            if (externos->pri==NULL)
            {
                externos->pri=aux;
                externos->ult=aux;
            }
            else
            {
                externos->pri->ant=aux;
                aux->sig=externos->pri;
                externos->pri=aux;
            }
        }
        act.pri=act.pri->sig;
    }
}

int BuscaApellido(TListaD listaord,char X[N])
{
    PNodoD act=listaord.pri;
    while (act->sig!=NULL && strcmp(act->Apellido,X)<0)
        act=act->sig;
    return !strcmp(act->Apellido,X);
}
