#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#define N 90

typedef struct nodito *SubLista;
typedef struct nodo *TLista;

typedef struct nodo{
    char Nombre[N];
    int Puntaje;
    struct nodo *sig;
    SubLista Sub;
}NodoL; //ESTO ES NODO DE EQUIPO

typedef struct nodito{
    char Jugador[N];
    struct nodito *sig;
    int edad;
}nodito;  //ESTO ES SUBLISTA DE JUGADORES

void CargaLista(TLista *lista);

void MuestraLista(TLista lista);

void Listar(TLista lista,TLista *lista2,char k,int *cantmax,char EquipoMayor[N],int *CantTot);

void MinimoPuntos(TLista lista,TLista *nuevalista,int x);

int main(){
    char k;
    int CantMax,CantTot,x;
    char EquipoMayor[N]={' '} ;
    TLista lista=NULL,lista2=NULL,nuevalista=NULL;
    CargaLista(&lista);
    printf("\n\n*****************PuntoA*****************\n\n");
    printf("Ingrese char k\n");
    scanf("%c",&k);
    MuestraLista(lista);
    Listar(lista,&lista2,k,&CantMax,EquipoMayor,&CantTot);
    MuestraLista(lista2);
    printf("El equipo con mas jugadores que empiezan con la letra %c es: %s, con un total de %d jugadores",k,EquipoMayor,CantMax);
    printf("\nLa cantidad total de jugadores que empiezan con la letra %c son: %d",k,CantTot);
    printf("\n\n*****************PuntoB*****************\n");
    printf("\nIngrese la cantidad de puntos minima para poder enlistar los equipos:\n");
    scanf("%d",&x);
    MinimoPuntos(lista,&nuevalista,x);
    printf("\n");
    MuestraLista(nuevalista);
    return 0;
}

void CargaLista(TLista *lista)
{
    FILE* Arch;
    TLista aux,act;
    SubLista auxsub,actsub;
    int punt,edad;
    char Equipo[N],Jugador[N];
    Arch=fopen("ej8.txt","rt");
    while (fscanf(Arch,"%s %d",Equipo,&punt)==2)
    {
        aux=(TLista)malloc(sizeof(NodoL));
        strcpy(aux->Nombre,Equipo);
        aux->Puntaje=punt;
        aux->sig=NULL;
        aux->Sub=NULL;
        while (fscanf(Arch,"%s %d",Jugador,&edad)==2)
        {
            auxsub=(SubLista)malloc(sizeof(nodito));
            strcpy(auxsub->Jugador,Jugador);
            auxsub->edad=edad;
            auxsub->sig=NULL;
            if (aux->Sub==NULL)
                aux->Sub=auxsub;
            else
            {
                actsub=aux->Sub;
                while (actsub->sig!=NULL)
                    actsub=actsub->sig;
                actsub->sig=auxsub;
            }
        }

        if (*lista==NULL)
            *lista=aux;
        else
        {
            act=*lista;
            while (act->sig!=NULL)
                act=act->sig;
            act->sig=aux;
        }
    }
    fclose(Arch);
}
void MuestraLista(TLista lista)
{
    SubLista auxsub;
    while (lista!=NULL)
    {
        printf("Equipo:%s, puntaje:%d\n",lista->Nombre,lista->Puntaje);
        auxsub=lista->Sub;
        while (auxsub!=NULL)
        {
            printf("Jugador:%s, edad:%d\n",auxsub->Jugador,auxsub->edad);
            auxsub=auxsub->sig;
        }
        printf("\n");
        lista=lista->sig;
    }
}
void Listar(TLista lista,TLista *lista2,char k,int *cantmax,char EquipoMayor[N],int *CantTot)
{
    SubLista auxsub,actsub,auxListaSub;
    TLista aux,act;
    int cant;
    *cantmax=*CantTot=0;
    while (lista!=NULL)
    {
        cant=0;
        aux=(TLista)malloc(sizeof(NodoL));
        strcpy(aux->Nombre,lista->Nombre);
        aux->Puntaje=lista->Puntaje;
        aux->sig=NULL;
        aux->Sub=NULL;
        auxListaSub=lista->Sub;
        while (auxListaSub!=NULL)
        {
            if (auxListaSub->Jugador[0]==k){
                (cant)++;
                auxsub=(SubLista)malloc(sizeof(nodito));
                auxsub->edad=auxListaSub->edad;
                auxsub->sig=NULL;
                strcpy(auxsub->Jugador,auxListaSub->Jugador);
                if (aux->Sub==NULL)
                    aux->Sub=auxsub;
                else
                {
                    actsub=aux->Sub;
                    while (actsub->sig!=NULL)
                        actsub=actsub->sig;
                    actsub->sig=auxsub;
                }
            }
            auxListaSub=auxListaSub->sig;
        }
        if (*lista2==NULL)
            *lista2=aux;
        else
        {
            act=*lista2;
            while (act->sig!=NULL)
                act=act->sig;
            act->sig=aux;
        }
        //******************************************//
        *CantTot+=cant;
        if (cant>*cantmax)
        {
            *cantmax=cant;
            strcpy(EquipoMayor,aux->Nombre);
        }
        lista=lista->sig;
    }
}

void MinimoPuntos(TLista lista,TLista *nuevalista,int x)
{
    TLista aux,act;
    int cont,suma;
    while (lista!=NULL)
    {
        if ((lista->Puntaje)>x)
        {
            aux=(TLista)malloc(sizeof(NodoL));
            strcpy(aux->Nombre,lista->Nombre);
            aux->Puntaje=lista->Puntaje;
            aux->Sub=lista->Sub;
            aux->sig=NULL;
            cont=0;
            suma=0;
            if (*nuevalista==NULL)
                *nuevalista=aux;
            else
            {
                act=*nuevalista;
                while (act->sig!=NULL)
                    act=act->sig;
                act->sig=aux;
            }
            //LUEGO DE CARGAR EL NODO, LO QUE HAGO ES RECORRER LA SUBLISTA PARA BUSCAR EL PROMEDIO DE EDAD DE LOS JUGADORES//
            while (lista->Sub!=NULL)
            {
                cont++;
                suma+=lista->Sub->edad;
                lista->Sub=lista->Sub->sig;
            }
            if (cont!=0)
                printf("\nEl promedio de edad del equipo %s es de: %f\n",lista->Nombre,((float)(suma/cont)));
            else
                printf("\nEl equipo no tiene jugadores xd\n");
        }
        lista=lista->sig;
    }
}