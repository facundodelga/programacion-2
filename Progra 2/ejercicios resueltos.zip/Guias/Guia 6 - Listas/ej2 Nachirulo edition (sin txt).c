#include <stdio.h>
#include <stdlib.h>

typedef struct nodo{
char dato;
struct nodo* sig;
} NodoL;

typedef NodoL* TLista;

void InsertarListaPrinc(TLista* lista, char elem);

void Mostrar(TLista lista);

int Vocales(TLista lista);

int Ordenada(TLista lista);

void Invertir(TLista* lista);

void EliminarPos(TLista* lista, int pos);

int main()
{
    int n = 5, i, pos;
    char v[] = {'a','b','c','d','e'};
    TLista lista = NULL;
    for (i=n-1;i>=0;i--)
        InsertarListaPrinc(&lista, v[i]);
    printf("Lista ingresada:\n");
    Mostrar(lista);
    printf("\n*****\n");
    if (Ordenada(lista))
        printf("La lista est� ordenada.");
    else
        printf("La lista no est� ordenada.");
    printf("\n*****\n");
    printf("La cantidad de vocales en la lista es %d.", Vocales(lista));
    printf("\n*****\n");
    printf("Invirtiendo la lista...\n");
    Invertir(&lista);
    Mostrar(lista);
    printf("\n*****\n");
    if (Ordenada(lista))
        printf("La lista est� ordenada.");
    else
        printf("La lista no est� ordenada.");
    printf("\n*****\n");
    printf("Ingrese la posici�n del elemento a eliminar.\n");
    scanf("%d", &pos);
    printf("*****\n");
    EliminarPos(&lista, pos);
    printf("Lista con el elemento de la posici�n %d eliminado:\n",pos);
    Mostrar(lista);
    printf("\n*****\n");
    return 0;
}

void InsertarListaPrinc(TLista* lista, char elem)
{
    TLista aux;
    aux = (TLista) malloc(sizeof(NodoL));
    aux->dato = elem;
    aux->sig = *lista;
    *lista = aux;
}

void Mostrar(TLista lista)
{
    while (lista != NULL)
    {
        printf("%c ", lista->dato);
        lista = lista->sig;
    }
}

int Vocales(TLista lista)
{
    int cant=0;
    while (lista != NULL)
    {
        if ((lista->dato == 'a') || (lista->dato == 'e') || (lista->dato == 'i') || (lista->dato == 'o') || (lista->dato == 'u'))
            cant++;
        lista = lista->sig;
    }
    return cant;
}

int Ordenada(TLista lista)
{
    TLista act, ant;
    if (lista == NULL)
        return 1;
    else
    {
        ant = lista;
        act = lista->sig;
        while ((act != NULL) && ((ant->dato) <= (act->dato)))
        {
            ant = act;
            act = act->sig;
        }
        if (act == NULL)
            return 1;
        else
            return 0;
    }
}

void Invertir(TLista* lista)
{
    TLista ant = NULL, post = (*lista)->sig;
    while (post != NULL)
    {
        (*lista)->sig = ant;
        ant = *lista;
        *lista = post;
        post = post->sig;
    }
    (*lista)->sig = ant;
}

void EliminarPos(TLista* lista, int pos)
{
    TLista ant = NULL, act = *lista;
    int i = 1;
    while ((act != NULL) && (i < pos))
    {
        i++;
        ant = act;
        act = act->sig;
    }
    if (act != NULL)
    {
        if (ant != NULL)
            ant->sig = act->sig;
        else
            *lista = act->sig;
        free(act);
    }
}
