#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#define N 100

typedef struct nodito *SubLista;
typedef struct nodo *TLista;

typedef struct nodo{
    char Carpeta[N];
    struct nodo *sig;
    char v[N];
    int CantArchivos;
    SubLista Sub;
}NodoL; //ESTO ES NODO DE CARPETA PRINCIPAL

typedef struct nodito{
    char CarpetaSub[N];
    struct nodito *sig;
}nodito;  //ESTO ES SUBLISTA DE CARPETAS Y ARCHIVOS

void CargaLista(TLista *lista);

void MuestraLista(TLista lista);

void BuscaCarpeta(TLista lista,char NombreCarpeta[N]);

int main(){
    TLista lista=NULL;
    char NombreCarpeta[N];
    CargaLista(&lista);
   // MuestraLista(lista);
    printf("Ingrese nombre de carpeta a buscar:");
    scanf("%s",NombreCarpeta);
    BuscaCarpeta(lista,NombreCarpeta);
    return 0;
}

void CargaLista(TLista *lista)
{
    FILE *Arch;
    TLista aux,act;
    SubLista auxsub,actsub;
    int EsSubCarpeta,archivo;
    char NombreCarpeta[N],SubCarpeta[N],basura[N],bandera[]="asd";
    Arch=fopen("ej9.txt","rt");
    while (fscanf(Arch,"%s",NombreCarpeta)==1)
    {
        aux=(TLista)malloc(sizeof(NodoL));
        strcpy(aux->Carpeta,NombreCarpeta);
        aux->Sub=NULL;
        aux->sig=NULL;
        aux->CantArchivos=0;
        while (fscanf(Arch," %d",&archivo))
            aux->v[(aux->CantArchivos)++]=archivo;
        fscanf(Arch,"%s",basura);
        fscanf(Arch,"%s",SubCarpeta);
        if (!(strncmp(SubCarpeta,NombreCarpeta,3)))
            EsSubCarpeta=0;
        else
            EsSubCarpeta=1;
        while (EsSubCarpeta)
        {
            auxsub=(SubLista)malloc(sizeof(nodito));
            strcpy(auxsub->CarpetaSub,SubCarpeta);
            auxsub->sig=NULL;
            if (aux->Sub==NULL)
                aux->Sub=auxsub;
            else
            {
                actsub=aux->Sub;
                while (actsub->sig!=NULL)
                    actsub=actsub->sig;
                actsub->sig=auxsub;
            }
            fscanf(Arch,"%s",SubCarpeta);
            if (!(strncmp(SubCarpeta,bandera,3)))
                EsSubCarpeta=0;
            else
                EsSubCarpeta=1;
        }
        if (*lista==NULL)
            *lista=aux;
        else
        {
            act=*lista;
            while (act->sig!=NULL)
                act=act->sig;
            act->sig=aux;
        }
    }
    fclose(Arch);
}
void MuestraLista(TLista lista)
{
    SubLista auxsub;
    int i;
    while (lista!=NULL)
    {
        printf("\nCarpeta principal: %s\n",lista->Carpeta);
        auxsub=lista->Sub;
        while (auxsub!=NULL)
        {
            printf("\nSubcarpeta: %s\n",auxsub->CarpetaSub);
            auxsub=auxsub->sig;
        }
        for (i=0;i<lista->CantArchivos;i++)
            printf("\nArchivo %d\n\n",lista->v[i]);
        lista=lista->sig;
    }
}

void BuscaCarpeta(TLista lista,char NombreCarpeta[N])
{
    int i;
    SubLista auxsub;
    while (lista!=NULL &&(strcmp(lista->Carpeta,NombreCarpeta))!=0)
        lista=lista->sig;
    if (lista!=NULL)
    {
        printf("\nNombre de la carpeta: %s",NombreCarpeta);
        for (i=0;i<lista->CantArchivos;i++)
            printf("\nArchivo %d\n\n",lista->v[i]);
        auxsub=lista->Sub;
        while (auxsub!=NULL)
        {
            printf("\nSubcarpeta: %s\n",auxsub->CarpetaSub);
            auxsub=auxsub->sig;

        }
    }
    else
        printf("\nno se encontr� la carpeta\n");
}
