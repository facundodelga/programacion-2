#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#define N 50

typedef struct nodoD{
    char Apellido[N],Nombre[N],Categoria;
    struct nodoD *ant,*sig;
}NodoD;
typedef struct nodoD *PNodoD;

typedef struct{
    PNodoD pri,ult;
}TListaD;

void CargaLista(TListaD *LD);

void OrdenaLista(TListaD LD,TListaD *lista);

void MuestraLista(TListaD lista);

int main(){
    TListaD LD,lista;
    lista.pri=NULL;
    lista.ult=NULL;
    LD.pri=NULL;
    LD.ult=NULL;
    CargaLista(&LD);
    MuestraLista(LD);
    printf("\n\n\n\n");
    OrdenaLista(LD,&lista);
    MuestraLista(lista);
    return 0;
}
void CargaLista(TListaD *LD)
{
    int i;
    char Apellido[N],Nombre[N],Categoria;
    PNodoD aux;
    for (i=1;i<5;i++)
    {
        scanf("%s",Apellido);
        scanf("\n%s",Nombre);
        scanf(" %c",&Categoria);
        aux=(PNodoD)malloc(sizeof(NodoD));
        strcpy(aux->Apellido,Apellido);
        strcpy(aux->Nombre,Nombre);
        aux->Categoria=Categoria;
        aux->sig=NULL;
        if (LD->pri==NULL)
        {
            aux->ant=NULL;
            LD->pri=aux;
            LD->ult=aux;
        }
        else
        {
            LD->ult->sig=aux;
            aux->ant=LD->ult;
            LD->ult=aux;
        }
    }
}

void OrdenaLista(TListaD LD,TListaD *lista)
{
    PNodoD act,aux,aux2;
    if (LD.pri!=NULL)
    {
        act=LD.pri;
        while (act!=NULL)
        {
            aux=act->sig;
            if (lista->pri==NULL)
            {
                lista->pri=act;
                lista->ult=act;
                lista->pri->sig=NULL;
            }
            else
            {
                if (strcmp(act->Apellido,lista->pri->Apellido)<1)//Si apellido del actual es menor o igual al apellido de la lista, entra al if
                {
                    aux=act;
                    aux=aux->sig;
                    lista->pri->ant=act;
                    act->sig=lista->pri;
                    act->ant=NULL;
                    lista->pri=act;
                }
                else
                {
                    if (strcmp(act->Apellido,lista->ult->Apellido)>-1)
                    {
                        lista->ult->sig=act;
                        act->ant=lista->ult;
                        act->sig=NULL;
                        lista->ult=act;
                    }
                    else
                    {
                        aux2=lista->pri->sig;
                        while (strcmp(act->Apellido,aux2->Apellido)>-1)
                            aux2=aux2->sig;
                        act->sig=aux2;
                        aux2->ant->sig=act;
                        act->ant=aux2->ant;
                        aux2->ant=act;
                    }
                }
            }
        act=aux;
        }
    }
}

void MuestraLista(TListaD lista)
{
    PNodoD aux=lista.pri;
    while (aux!=NULL)
    {
        printf("\nApellido: %s",aux->Apellido);
        aux=aux->sig;
    }
}
