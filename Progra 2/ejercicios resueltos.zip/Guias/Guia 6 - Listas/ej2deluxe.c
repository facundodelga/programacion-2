#include <stdio.h>
#include <stdlib.h>

typedef struct nodo{
char dato;
struct nodo *sig;
}NodoL;

typedef NodoL *TLista;

void muestra(TLista lista);

int vocales(TLista lista);

int Ordenado(TLista lista);

void Invierte(TLista* lista);

void EliminaPos(TLista* lista,int pos);

void GeneraLista(TLista* lista,char elem);
int main()
{
    FILE *Arch;
    Arch=fopen("ej2.txt","rt");
    char elem1;
    int pos;
    TLista lista;
    lista=NULL;
    while ((fscanf(Arch,"%c ",&elem1))==1)
        GeneraLista(&lista,elem1);
    muestra(lista);
    printf("\n%d",vocales(lista));
    fclose(Arch);
    if (Ordenado(lista))
        printf("\nesta ordenado\n");
    else
        printf("\nno\n");
    //Invierte(&lista);
    //muestra(lista);
    printf("\nIngresa posicion para eliminar\n");
    scanf("%d",&pos);
    EliminaPos(&lista,pos);
    muestra(lista);
    return 0;
}
void GeneraLista(TLista* lista,char elem)
{
    TLista aux,act;
    aux = (TLista) malloc (sizeof(NodoL));
    aux->dato=elem;
    aux->sig=NULL;
    if ((*lista)==NULL)
        *lista=aux;
    else
    {
        act=*lista;
        while ((act->sig)!=NULL)
        {
            act=act->sig;
        }
        act->sig=aux;
    }
}
void muestra(TLista lista)
{
    while (lista!=NULL)
    {
        printf("%c",lista->dato);
        lista=lista->sig;
    }
}
int vocales(TLista lista)
{
    int cant=0;
    while (lista!=NULL)
    {
        if ((lista->dato=='a') || (lista->dato=='e') || (lista->dato=='i') || (lista->dato=='o') || (lista->dato=='u'))
            cant++;
        lista=lista->sig;
    }
    return cant;
}
int Ordenado(TLista lista)
{
    TLista act,ant;
    if (lista==NULL)
        return 1;
    else
    {
        ant=lista;
        act=lista->sig;
        while ((act!=NULL) && ((ant->dato)<=(act->dato)))
        {
            ant=act;
            act=act->sig;
        }
        if (act==NULL || (ant->dato)<=(act->dato))
            return 1;
        else
            return 0;
    }
}

void Invierte(TLista* lista)
{
    TLista ant=NULL,post=(*lista)->sig;
    while (post!=NULL)
    {
        (*lista)->sig=ant;
        ant=*lista;
        *lista=post;
        post=post->sig;
    }
    (*lista)->sig=ant;
}
void EliminaPos(TLista* lista,int pos)
{
    TLista ant=NULL,act=*lista;
    int i=1;
    while (act!=NULL && i<(pos))
    {
        i++;
        ant=act;
        act=act->sig;
    }
    if (act!=NULL)
    {
        if (ant!=NULL)
            ant->sig=act->sig;
        else
            *lista=act->sig;
        free(act);
    }

}
