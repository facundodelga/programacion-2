#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#define N 20

typedef struct nodito *SubLista;
typedef struct nodo *TLista;
typedef struct nodito2 *SubSubLista;

typedef struct nodo{
    char Destino[N];
    struct nodo *sig;
    SubLista Sub;
}NodoL; //ESTO ES NODO DE DESTINOS

typedef struct nodito{
    char Codigo[N];
    char FechayHorario[N];
    int Capacidad;
    struct nodito *sig;
    SubSubLista SubPasajeros;
}nodito;  //ESTO ES SUBLISTA DE VUELOS

typedef struct nodito2{
    int DNI;
    struct nodito2 *sig;
}nodito2; //ESTO ES UNA SUBLISTA DE LA SUBLISTA, QUE ALMACENA LOS DOCUMENTOS DE LOS VIAJEROS DEL VUELO DE LA SUBLISTA

void GeneraLista(TLista *lista);

void Reserva(TLista lista);

void MuestraLista(TLista lista);

void Elimina(TLista lista);

int main(){
    TLista lista=NULL;
    GeneraLista(&lista);
    MuestraLista(lista);
    printf("\n\n\n\nRESERVA\n\n\n\n");
    Reserva(lista);
    MuestraLista(lista);
    printf("\n\n\n\nELIMINA\n\n\n\n");
    Elimina(lista);
    MuestraLista(lista);
    return 0;
}

void GeneraLista(TLista *lista)
{
    TLista aux,act;
    SubLista auxsub,actsub;
    SubSubLista auxsubsub,actsubsub;
    char Destino[N],Codigo[N],FechayHorario[N],basura,op;
    int Capacidad,DNI;
    printf("Nuevo Destino? ");
    scanf("%c",&op);
    scanf("%c",&basura);
    while (op=='S')
    {
        printf("\nDestino: ");
        scanf("%s",Destino);
        scanf("%c",&basura);
        aux=(TLista)malloc(sizeof(NodoL));
        strcpy(aux->Destino,Destino);
        aux->sig=NULL;
        aux->Sub=NULL;
        printf("\nNuevo Codigo? ");
        scanf("%c",&op);
        scanf("%c",&basura);
        while (op=='S')
        {
            printf("\nCodigo: ");
            scanf("%s",Codigo);
            scanf("%c",&basura);
            printf("\nFechayHorario y Capacidad: ");
            scanf("%s",FechayHorario);
            scanf("%c",&basura);
            scanf("%d",&Capacidad);
            scanf("%c",&basura);
            auxsub=(SubLista)malloc(sizeof(nodito));
            strcpy(auxsub->Codigo,Codigo);
            strcpy(auxsub->FechayHorario,FechayHorario);
            auxsub->Capacidad=Capacidad;
            auxsub->sig=NULL;
            auxsub->SubPasajeros=NULL;
            printf("\nDocumentos de pasajeros: ");
            while (scanf("%d",&DNI)==1)
            {
                scanf("%c",&basura);
                auxsubsub=(SubSubLista)malloc(sizeof(nodito2));
                auxsubsub->DNI=DNI;
                auxsubsub->sig=NULL;
                if (auxsub->SubPasajeros==NULL)
                    auxsub->SubPasajeros=auxsubsub;
                else
                {
                    actsubsub=auxsub->SubPasajeros;
                    while (actsubsub->sig!=NULL)
                        (actsubsub)=(actsubsub)->sig;
                    (actsubsub->sig)=auxsubsub;
                }
            }
            if (aux->Sub==NULL)
                aux->Sub=auxsub;
            else
            {
                actsub=aux->Sub;
                while (actsub->sig!=NULL)
                    actsub=actsub->sig;
                actsub->sig=auxsub;
            }
            scanf("%c",&basura);
            printf("\nNuevo Codigo?\n");
            scanf(" %c",&op);
            scanf("%c",&basura);
        }
        if (*lista==NULL)
            *lista=aux;
        else
        {
            act=*lista;
            while (act->sig!=NULL)
                act=act->sig;
            act->sig=aux;
        }
    printf("\nNuevo Destino?");
    scanf("%c",&op);
    scanf("%c",&basura);
    }
    printf("\n\n\n\n");
}

void Reserva(TLista lista)
{
    char Destino[N],Codigo[N],basura;
    SubSubLista auxsubsub,actsubsub;
    TLista aux;
    int DNI;
    printf("\nIngrese Destino para reservar:");
    scanf("%s",Destino);
    aux=lista;
    while (aux!=NULL && strcmp(aux->Destino,Destino)!=0)
        aux=aux->sig;
    if (aux!=NULL)
    {
        printf("\nIngrese Codigo para reservar: ");
        scanf("%c",&basura);
        scanf("%s",Codigo);
        while ((aux->Sub)!=NULL && strcmp(aux->Sub->Codigo,Codigo)!=0)
            aux->Sub=aux->Sub->sig;
        if ((aux->Sub)!=NULL)
        {
            printf("\nIngrese DNI de la persona a reservar: ");
            scanf("%d",&DNI);
            auxsubsub=(SubSubLista)malloc(sizeof(nodito2));
            auxsubsub->DNI=DNI;
            auxsubsub->sig=NULL;
            if (aux->Sub->SubPasajeros==NULL)
                aux->Sub->SubPasajeros=auxsubsub;
            else
            {
                actsubsub=aux->Sub->SubPasajeros;
                while (actsubsub->sig!=NULL)
                    actsubsub=actsubsub->sig;
                actsubsub->sig=auxsubsub;
            }
        }
        else
            printf("\nEl codigo no existe\n");
    }
    else
        printf("\nEl destino no existe\n");
}

void MuestraLista(TLista lista)
{
    TLista aux;
    SubLista auxsub;
    SubSubLista auxsubsub;
    aux=lista;
    while (aux!=NULL)
    {
        printf("Destino: %s\n",aux->Destino);
        auxsub=aux->Sub;
        while (auxsub!=NULL)
        {
            printf("Codigo: %s\n",auxsub->Codigo);
            printf("Fecha: %s\n",auxsub->FechayHorario);
            printf("Capacidad: %d\n",auxsub->Capacidad);
            auxsubsub=auxsub->SubPasajeros;
            while (auxsubsub!=NULL)
            {
                printf("DNI pasajero:%d\n",auxsubsub->DNI);
                auxsubsub=auxsubsub->sig;
            }
        auxsub=auxsub->sig;
        printf("\n\n");
        }
    printf("\n\n\n\n");
    aux=aux->sig;
    }
}

void Elimina(TLista lista)
{
    char Destino[N],Codigo[N],basura;
    SubSubLista actsubsub,antsubsub;
    TLista aux;
    int DNI;
    printf("\nIngrese Destino para eliminar:");
    scanf("%s",Destino);
    aux=lista;
    while (aux!=NULL && strcmp(aux->Destino,Destino)!=0)
        aux=aux->sig;
    if (aux!=NULL)
    {
        printf("\nIngrese Codigo para eliminar: ");
        scanf("%c",&basura);
        scanf("%s",Codigo);
        while ((aux->Sub)!=NULL && strcmp(aux->Sub->Codigo,Codigo)!=0)
            aux->Sub=aux->Sub->sig;
        if ((aux->Sub)!=NULL)
        {
            printf("\nIngrese DNI de la persona a eliminar: ");
            scanf("%d",&DNI);
            antsubsub=NULL;
            actsubsub=aux->Sub->SubPasajeros;
            while ((actsubsub)!=NULL && (actsubsub->DNI)!=DNI)
            {
                antsubsub=actsubsub;
                actsubsub=actsubsub->sig;
            }
           // if (antsubsub==NULL) ESTO NO ANDA, PREGUNTAR
               // actsubsub=actsubsub->sig;
            if (antsubsub==NULL)
                aux->Sub->SubPasajeros=aux->Sub->SubPasajeros->sig;
            else
            {
                if (actsubsub==NULL)
                    printf("No existe el DNI a eliminar");
                else
                    antsubsub->sig=actsubsub->sig;
            }
            free (actsubsub);
        }
        else
            printf("\nEl codigo no existe\n");
    }
    else
        printf("\nEl destino no existe\n");
}
