#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define N 50

typedef struct nodo{
char dato[N];
int cant;
struct nodo *sig;
}NodoL;

typedef NodoL *TLista;

void Inserta(TLista *lista,char elem[N]);

void muestra(TLista lista);

int main()
{
    TLista lista=NULL;
    char elem[N];
    FILE *Arch;
    Arch=fopen("ej3.txt","rt");
    while ((fscanf(Arch,"%s",elem))==1)
        Inserta(&lista,elem);
    muestra(lista);
    return 0;
}
void Inserta(TLista *lista,char elem[N])
{
    TLista aux=*lista,act,ant;

    if (aux==NULL)
    {
        aux=(TLista)malloc(sizeof(NodoL));
        strcpy(aux->dato,elem);
        aux->cant=1;
        aux->sig=NULL;
        *lista=aux;
    }
    else
    {
        ant=NULL;
        act=(*lista);
        while (act!=NULL && (strcmp(elem,act->dato)>0))
        {
            ant=act;
            act=act->sig;
        }
        if (act==NULL)
        {
            aux=(TLista)malloc(sizeof(NodoL));
            ant->sig=aux;
            aux->cant=1;
            aux->sig=NULL;
            strcpy(aux->dato,elem);
        }
        else
            if (strcmp(elem,act->dato)==0)
                (act->cant)++;
            else
            {
                aux=(TLista)malloc(sizeof(NodoL));
                aux->cant=1;
                strcpy(aux->dato,elem);
                aux->sig=act;
                if (ant==NULL)
                    *lista=aux;
                else
                    ant->sig=aux;
            }
    }
}
void muestra(TLista lista)
{
    while (lista!=NULL)
    {
        printf("%s\t",lista->dato);
        printf("%d\n",lista->cant);
        lista=lista->sig;
    }
}
