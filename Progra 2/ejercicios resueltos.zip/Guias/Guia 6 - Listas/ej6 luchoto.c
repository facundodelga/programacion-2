#include <stdlib.h>
#include <stdio.h>
typedef struct nodo{
    int dato;
    struct nodo *sig;
}NodoL;
typedef NodoL* TLista;

void CargaLista(TLista* lista);

void SeparaListas(TLista lista,TLista *listaPar,TLista *listaImp);

void MuestraLista(TLista lista);

int main(){
    TLista lista=NULL,listaImp,listaPar;
    CargaLista(&lista);
    MuestraLista(lista);
    SeparaListas(lista,&listaPar,&listaImp);
    printf("\n");
    MuestraLista(listaPar);
    printf("\n");
    MuestraLista(listaImp);
    return 0;
}

void CargaLista(TLista* lista)
{
    int elem;
    TLista aux,act;
    while (scanf("%d",&elem)==1)
    {
        aux=(TLista)malloc(sizeof(NodoL));
        aux->dato=elem;
        aux->sig=NULL;
        if (*lista==NULL)
            *lista=aux;
        else
        {
            act=*lista;
            while (act->sig!=NULL)
                act=act->sig;
            act->sig=aux;
        }
    }
}
void SeparaListas(TLista lista,TLista *listaPar,TLista *listaImp)
{
    TLista actPar,aux;
    int elem;
    *listaPar=*listaImp=NULL;
    while (lista!=NULL)
    {
        aux=lista->sig;
        elem=lista->dato;
        if (elem%2==0)
        {
            lista->sig=NULL;
            if(*listaPar!=NULL){
                actPar->sig=lista;
                actPar=actPar->sig;
            }
            else{
                *listaPar=lista;
                actPar=*listaPar;
            }
        }
        else
        {
            lista->sig=*listaImp;
            *listaImp=lista;
        }
        lista=aux;
    }
}
void MuestraLista(TLista lista)
{
    while (lista!=NULL)
    {
        printf("%d \t",lista->dato);
        lista=lista->sig;
    }
}
