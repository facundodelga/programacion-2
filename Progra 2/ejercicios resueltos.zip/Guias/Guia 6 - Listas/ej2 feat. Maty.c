#include <stdio.h>
#include <stdlib.h>

typedef struct nodo {
   char dato;
   struct nodo* sig;
} nodo;
typedef nodo* TLista;

void carga(TLista*);
void muestra(TLista);
int vocales(TLista);
void inversa(TLista*);
void quita(TLista*,unsigned int);

int main() {
   TLista lc=NULL;
   carga(&lc); //se carga de atras
   muestra(lc);
   printf("\n Cantidad de vocales: %d",vocales(lc));
   //quita(&lc,1);
   printf("\n");
   printf("%d",orden(lc));
   inversa(&lc);
   muestra(lc);
   return 0;
}

void carga(TLista* li) {
   FILE* arch;
   char c;
   TLista aux;
   arch=fopen("car.txt","rt");
   if(fscanf(arch,"%c",&c)==1) {
      *li=(TLista)malloc(sizeof(nodo));
      (**li).dato=c;
      (**li).sig=NULL;
      while(fscanf(arch,"%c",&c)==1) {
         aux=(TLista)malloc(sizeof(nodo));
         aux->dato=c;
         aux->sig=*li;
         *li=aux;
      }
   }
   fclose(arch);
}

void muestra(TLista li) {
   while(li->sig!=NULL) {
      printf("%c",li->dato);
      li=li->sig;
   }
   printf("%c",li->dato);
}

int orden(TLista li) {
    TLista ant;
   int boolean=1;
   if(li){
        ant=li;
        li=li->sig;
        while(boolean && li->sig){
            if(ant->dato >= li->dato)
                boolean=0;
        ant=li;
        li=li->sig;
        }
   } else {
      boolean=0;
   }
   return boolean;
}

int vocales(TLista li) {
   int cont=0;
   char aux;
   while(li->sig!=NULL) {
      aux=li->dato;
      if(aux=='a'||aux=='e'||aux=='i'||aux=='o'||aux=='u')
         cont++;
      li=li->sig;
   }
   return cont;
}

void inversa(TLista* li) {
   TLista aux=NULL,act=NULL,ant=NULL;
   if (li || (*li)->sig) {
      act=*li;
      do {
         aux=act->sig;
         act->sig=ant;
         ant=act;
         act=aux;
      } while(act);
      *li=ant;
   }
}

//FUNCIONA PERO MUY REBUSCADO
/*void inversa(TLista* li){
    TLista aux,ant;
    if(*li!=NULL || ((*li)->sig)!= NULL){
        if((*li)->sig->sig == NULL){
            aux=(*li)->sig;
            (*li)->sig=NULL;
            aux->sig=*li;
            *li=aux;
        }else{
            aux=(*li)->sig;
            ant=aux->sig;
            (*li)->sig=NULL;
            aux->sig=*li;
            *li=aux;
            while((aux->sig)!=NULL){
                aux=ant->sig;
                ant->sig=*li;
                (*li)=ant;
                ant=aux;
            }
            aux->sig=*li;
            *li=aux;
        }
    }
}
*/

//se puede mejorar
void quita(TLista* li,unsigned int i) {
   TLista aux,next,ant;
   int cont;
   if(i==0) {
      aux=*li;
      *li=aux->sig;
      free(aux);
   } else {
      cont=0;
      next=*li;
      while((next->sig)!=NULL && cont!=i) {
         ant=next;
         cont++;
         next=next->sig;
      }
      if(i==cont) {
         aux=next;
         ant->sig=next->sig;
         free(aux);
      } else {
         if(cont+1==i) {
            aux=ant->sig;
            ant->sig=NULL;
            free(aux);
         }
      }
   }
}
