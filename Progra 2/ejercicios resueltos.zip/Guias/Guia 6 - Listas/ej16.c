#include <stdlib.h>
#include <stdio.h>

typedef struct nodoC{
    int num;
    struct nodoC *sig;
}NodoC;

typedef NodoC* TListaC;

void CreaLista(TListaC* lista, int v[], int n);

void MuestraLista(TListaC lista);

void EliminaElem(TListaC* lista, int elem, int* elimino);

int main(){
    int v[] = {1,2,3,4,5}, n=5, x, elimino;
    TListaC lista;
    CreaLista(&lista, v, n);
    printf("Lista original:\n");
    MuestraLista(lista);
    printf("\n*****\n");
    printf("Ingrese el elemento a eliminar.\n");
    scanf("%d",&x);
    printf("\n*****\n");
    EliminaElem(&lista, x, &elimino);
    if (elimino)
    {
        printf("Nueva lista:\n");
        MuestraLista(lista);
    }
    else
        printf("No se elimin� el elemento ingresado.");
    return 0;
}

void CreaLista(TListaC* lista, int v[], int n)
{
    TListaC aux;
    int i;
    *lista = NULL;
    for (i=0;i<n;i++)
    {
        aux = (TListaC) malloc(sizeof(NodoC));
        aux->num = v[i];
        if (*lista == NULL)
        {
            *lista = aux;
            aux->sig = aux;
        }
        else
        {
            aux->sig = (*lista)->sig;
            *lista = (*lista)->sig = aux;
        }
    }
}

void MuestraLista(TListaC lista)
{
    TListaC act = lista;
    if (act != NULL)
        do
        {
            act = act->sig;
            printf("%d ", act->num);
        } while (act != lista);
}

void EliminaElem(TListaC* lista, int elem, int* elimino)
{
    TListaC ant, act = *lista;
    *elimino = 0;
    if (*lista != NULL)
    {
        do
        {
            ant = act;
            act = act->sig;
        } while (*lista != act && elem > act->num);
        if (elem == act->num)
        {
            if (*lista == (*lista)->sig)
                *lista = NULL;
            else
            {
                ant->sig = act->sig;
                if (act == *lista)
                    *lista = ant;
            }
            free (act);
            *elimino = 1;
        }
    }
}
