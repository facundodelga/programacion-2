#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#define N 26

typedef struct nodo *TLista;
typedef struct nodito *SubLista;
typedef TLista V[N];

typedef struct nodo{
    char Autor[N];
    struct nodo *sig;
    SubLista Sub;
}NodoL;

typedef struct nodito{
    char Titulo[N];
    int Anio;
    struct nodito *sig;
}nodito;

void CargaLista(TLista V[N]);

void MuestraLista(TLista V[N]);

void AgregaLibro(TLista V[N]);

int main(){
    TLista V[N]={};
    CargaLista(V);
    MuestraLista(V);
    AgregaLibro(V);
    MuestraLista(V);
    return 0;
}

void CargaLista(TLista V[N])
{
    int i,Anio;
    TLista aux,act;
    SubLista auxsub,actsub;
    char op,basura,Autor[N],Titulo[N];
    for (i=0;i<2;i++)
    {
        printf("Desea agregar autores con nombre %c? ",('a'+i));
        scanf("%c",&op);
        scanf("%c",&basura);
        while (op=='S')
        {
            printf("\nIngrese autor: ");
            scanf("%s",Autor);
            scanf("%c",&basura);
            aux=(TLista)malloc(sizeof(NodoL));
            strcpy(aux->Autor,Autor);
            aux->sig=NULL;
            aux->Sub=NULL;
            printf("\nDesea ingresar libros a nombre de %s? ",Autor);
            scanf("%c",&op);
            scanf("%c",&basura);
            while (op=='S')
            {
                printf("\nIngrese libro: ");
                scanf("%s",Titulo);
                scanf("%c",&basura);
                printf("\nIngrese anio del libro: ");
                scanf("%d",&Anio);
                scanf("%c",&basura);
                auxsub=(SubLista)malloc(sizeof(nodito));
                strcpy(auxsub->Titulo,Titulo);
                auxsub->Anio=Anio;
                auxsub->sig=NULL;
                if (aux->Sub==NULL)
                    aux->Sub=auxsub;
                else
                {
                    actsub=aux->Sub;
                    while (actsub->sig!=NULL)
                        actsub=actsub->sig;
                    actsub->sig=auxsub;
                }
                printf("\n Desea ingresar otro libro a nombre de %s? ",Autor);
                scanf("%c",&op);
                scanf("%c",&basura);
            }
            if (V[i]==NULL)
                V[i]=aux;
            else
            {
                act=V[i];
                while (act->sig!=NULL)
                    act=act->sig;
                act->sig=aux;
            }
            printf("\nDesea ingresar otro autor? ");
            scanf("%c",&op);
            scanf("%c",&basura);
        }
    }
}
void MuestraLista(TLista V[N])
{
    int i;
    TLista aux;
    SubLista auxsub;
    for (i=0;i<N;i++)
    {
        if (V[i]!=NULL)
        {
            aux=V[i];
            while (aux!=NULL)
            {
                printf("\nEl autor con nombre %s tiene estos libros, con sus respectivos a�os: ",aux->Autor);
                auxsub=aux->Sub;
                while (auxsub!=NULL)
                {
                    printf("%s ",auxsub->Titulo);
                    printf("%d\t",auxsub->Anio);
                    auxsub=auxsub->sig;
                }
                printf("\n\n");
                aux=aux->sig;
            }
        }
        else
            printf("\nNo hay autores con nombre %c\n",('a'+i));
    }
}
void AgregaLibro(TLista V[N])
{
    TLista aux;
    SubLista auxsub,actsub,antsub;
    int anio;
    char letra,basura,autor[N],Titulo[N];
    printf("\nIngrese letra con la que empieza el nombre del autor: ");
    scanf("%c",&letra);
    scanf("%c",&basura);
    aux=V[letra-'a'];
    if (aux!=NULL)
    {
        printf("\nIngrese autor: ");
        scanf("%s",autor);
        scanf("%c",&basura);
        while ((aux!=NULL) && strcmp(aux->Autor,autor)!=0)
            aux=aux->sig;
        if (aux!=NULL)
        {
            printf("\nIngrese libro:");
            scanf("%s",Titulo);
            scanf("%c",&basura);
            printf("\nIngrese anio del libro: ");
            scanf("%d",&anio);
            auxsub=(SubLista)malloc(sizeof(nodito));
            strcpy(auxsub->Titulo,Titulo);
            auxsub->Anio=anio;
            auxsub->sig=NULL;
            antsub=NULL;
            actsub=aux->Sub;
            if (aux->Sub!=NULL)
            {
                 while (actsub!=NULL && strcmp(actsub->Titulo,Titulo)<0)
                {
                    antsub=actsub;
                    actsub=actsub->sig;
                }
                if (actsub==NULL)
                    antsub->sig=auxsub;
                else
                    if (antsub==NULL)
                    {
                        auxsub->sig=actsub;
                        aux->Sub=auxsub;
                    }
                    else
                    {
                        antsub->sig=auxsub;
                        auxsub->sig=actsub;
                    }
            }
            else
                aux->Sub=auxsub;

        }
        else
            printf("No se encontro el autor");
    }
}
