#include <stdio.h>
#include <stdlib.h>
#define M 15

int MaxFila(int A[][M],int m, int i);

int main()
{
    int A[M][M],V[M], n, m, i, j;
    printf("Ingrese las dimensiones de la matriz.\n");
    scanf("%d %d",&n,&m);
    for (i=0;i<n;i++)
    {
        printf("Fila.\n");
        for (j=0;j<m;j++)
            scanf("%d",&A[i][j]);
    }
    for (i=0;i<n;i++)
        V[i]=MaxFila(A,m-1,i);
    for (i=0;i<n;i++)
        printf("\nEl m�ximo de la fila %d es %d",i+1,V[i]);
    return 0;
}

int MaxFila(int A[][M],int m, int i)
{
    if (m == 0)
        return A[i][0];
    else
        if (A[i][m]>MaxFila(A,m-1,i))
            return A[i][m];
}
