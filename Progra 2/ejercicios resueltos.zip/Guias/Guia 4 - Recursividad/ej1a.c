#include <stdio.h>
#include <stdlib.h>
#define N 50

int Suma(int V[], int n);

void Muestra(int V[], int n);

void MuestraInvertido(int V[], int n);

int main()
{
    int V[N];
    unsigned int n, i;
    printf("Ingrese la cantidad de elementos del vector.\n");
    scanf("%u",&n);
    printf("Ingrese los elementos del vector.\n");
    for (i=0;i<n;i++)
        scanf("%d",&V[i]);
    printf("*****\nEl vector ingresado es:\n");
    Muestra(V,n-1);
    printf("\n*****\nEl vector invertido es:\n");
    MuestraInvertido(V,n-1);
    printf("\n*****\nLa suma de los elementos ingresados es %d.",Suma(V,n-1));
    return 0;
}

int Suma(int V[], int n)
{
    if (n == 0)
        return V[0];
    else
        return V[n]+Suma(V,n-1);
}

void Muestra(int V[], int n)
{
    if (n > 0)
        Muestra(V,n-1);
    printf("%d   ",V[n]);
}

void MuestraInvertido(int V[], int n)
{
    printf("%d   ",V[n]);
    if (n > 0)
        MuestraInvertido(V,n-1);
}
