#include <stdio.h>
#include <stdlib.h>
#define M 15

int Condiciones(int a[][M], int i, int j, int n, int m, int suma, int sumaAnt);

int main()
{
    int a[][M] = {{-1,-2,-3},{4,5,6},{7,8,9},{11,11,11}}, b[][M] = {{4,7,7},{8,1,1},{1,4,3},{1,7,8}}, n = 4, m = 3;
    printf("Matriz A: %d\nMatriz B: %d",Condiciones(a,0,0,n-1,m-1,0,0),Condiciones(b,0,0,n-1,m-1,0,0));
    return 0;
}

int Condiciones(int a[][M], int i, int j, int n, int m, int suma, int sumaAnt)
{
    if (i<=n)
        if (j<=m)
        {
            suma += a[i][j];
            return Condiciones(a,i,j+1,n,m,suma,sumaAnt);
        }
        else
            return ((i==0 && (!(suma % 2))) || ((i!=0) &&(suma >= sumaAnt))) //retorna 1 si no es la primera fila y la suma es mayor a la anterior o si es la primera fila y la suma de sus elementos es par
                    && (Condiciones(a,i+1,0,n,m,0,suma)); //retorna 1 si la anterior fila cumpl�a con las condiciones
}

