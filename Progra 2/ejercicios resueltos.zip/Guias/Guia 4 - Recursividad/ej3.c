#include <stdio.h>
#include <stdlib.h>

float Promedio(int v[], int i, int n);

int main()
{
    int v[] = {8,-9,7,9,4}, n = 5;
    printf("%3.2f",Promedio(v,n-1,n));
    return 0;
}

float Promedio(int v[], int i, int n)
{
    if (n!=0)
        if (i==0)
            return ((float) v[i] / n);
        else
            return (((float) v[i] / n) + Promedio(v,i-1,n));
    else
        return 0;
}
