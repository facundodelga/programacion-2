#include <stdio.h>
#include <stdlib.h>
#define M 15

int BuscaInt(float a[][M], int i, int j, int m, float x);

void BuscaVoid (float a[][M], int i, int j, int m, float x, int *cant);

int main()
{
    float a[][M] = {{-4.2,69,7},{6.6,-8,7},{7,8,9},{9.8,7,8}},x;
    int n = 4, m = 3, cant;
    printf("Ingrese el valor a buscar en la matriz.\n");
    scanf("%f",&x);
    printf("\nInt: %d",BuscaInt(a,n-1,m-1,m-1,x));
    BuscaVoid(a,n-1,m-1,m-1,x,&cant);
    printf("\nVoid: %d",cant);
    return 0;
}

int BuscaInt(float a[][M], int i, int j, int m, float x)
{
    if (i>=0)
        if (j>0)
            return BuscaInt(a,i,j-1,m,x) + (a[i][j] == x);
        else
            return BuscaInt(a,i-1,m,m,x) + (a[i][j] == x);
    else
        return 0;
}

void BuscaVoid (float a[][M], int i, int j, int m, float x, int *cant)
{
    if (i>=0)
    {
        if (j>0)
            BuscaVoid(a,i,j-1,m,x,cant);
        else
            BuscaVoid(a,i-1,m,m,x,cant);
        *cant += (a[i][j] == x);
    }
    else
        *cant = 0;
}
