#include <stdio.h>
#include <stdlib.h>

unsigned int BuscaLineal(float A[], int n, float X);

int main()
{
    float X, A[6]={-69,4,7.5,9.9,420,421};
    int n = 6;
    printf("Ingrese el valor a buscar en el arreglo.\n");
    scanf("%f",&X);
    printf("*****\nLa posici�n de %3.2f es %u.\n",X,BuscaLineal(A,n-1,X));
    return 0;
}

unsigned int BuscaLineal(float A[], int n, float X)
{
    if (n<0)
        return 0;
    else
        if (A[n] == X)
            return n+1;
        else
            return BuscaLineal(A,n-1,X);
}
