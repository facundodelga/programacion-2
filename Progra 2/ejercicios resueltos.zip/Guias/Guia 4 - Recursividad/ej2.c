#include <stdio.h>
#include <stdlib.h>

int Prod(int a, int b);

void CocienteResto(int a, int b, int *coc, int *res);

int  MaximoInt(int v[], int n);

void MaximoVoid(int v[], int n, int *maximo);

int main()
{
    int coc, res, a = 3, b = 12, c = 123, d = 9, v[] = {4,99,-7,92,77}, n = 5, maximo;
    printf("El producto entre %d y %d es %d.",a,b,Prod(a,b));
    CocienteResto(c,d,&coc,&res);
    printf("\n*****\nEl cociente entre %d y %d es %d y su resto es %d.",c,d,coc,res);
    printf("\n*****\n(int) El elemento m�ximo del vector ingresado es %d.",MaximoInt(v,n-1));
    MaximoVoid(v,n-1,&maximo);
    printf("\n*****\n(void) El elemento m�ximo del vector ingresado es %d.",maximo);
    return 0;
}

int Prod(int a, int b)
{
    if (b==0)
        return 0;
    else
        return a + Prod(a,b-1);
}

void CocienteResto(int a, int b, int *coc, int *res)
{
    if (a<b)
    {
        *res = a;
        *coc = 0;
    }
    else
    {
        CocienteResto(a-b,b,coc,res);
        *coc += 1;
    }
}

int  MaximoInt(int v[], int n)
{
    int aux;
    if (n==0)
        return v[0];
    else
    {
        aux = MaximoInt(v,n-1);
        if (v[n]>aux)
            return v[n];
        else
            return aux;
    }
}

void MaximoVoid(int v[], int n, int *maximo)
{
    if (n==0)
        *maximo = v[0];
    else
    {
        MaximoVoid(v,n-1,maximo);
        if (v[n] > (*maximo))
            *maximo = v[n];
    }
}
