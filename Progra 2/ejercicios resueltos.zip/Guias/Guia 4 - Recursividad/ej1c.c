#include <stdio.h>
#include <stdlib.h>
#define N 15

int Minimo(int M[][N], int i, int j, int n);

int main()
{
    int M[N][N], n, i, j;
    printf("Ingrese la dimensi�n de la matriz.\n");
    scanf("%d",&n);
    for (i=0;i<n;i++)
    {
        printf("Fila.\n");
        for (j=0;j<n;j++)
            scanf("%d",&M[i][j]);
    }
    printf("El m�nimo es %d",Minimo(M,n-1,n-1,n-1));
    return 0;
}

int Minimo(int M[][N], int i, int j, int n)
{
    int aux;
    if ((i == 0) && (j == 0))
        return M[0][0];
    else
        if (j>0)
        {
            aux = Minimo(M,i,j-1,n);
            if (M[i][j] < aux)
                return M[i][j];
            else
                return aux;
        }
        else
        {
            aux = Minimo(M,i-1,n,n);
            if (M[i][j] < aux)
                return M[i][j];
            else
                return aux;
        }
}
