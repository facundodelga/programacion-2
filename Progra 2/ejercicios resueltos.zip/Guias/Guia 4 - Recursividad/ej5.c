#include <stdio.h>
#include <stdlib.h>
#define N 15

int Simetrica(int a[][N], int i, int j, int m);

int main()
{
    int a[][N] = {{2,3,4,32},{5,6,7,24},{4,7,3,11},{8,9,7,10}}, b[][N] = {{1,2,3},{2,1,4},{3,4,1}}, n;
    n = 4;
    printf("Matriz a: %d",Simetrica(a,n-1,n-1,n-1));
    n = 3;
    printf("\nMatriz b: %d",Simetrica(b,n-1,n-1,n-1));
    return 0;
}

int Simetrica(int a[][N], int i, int j, int m)
{
    if (j<0)
        return 1;
    else
        if (j>0)
            return ((a[i][j] == a[j][i]) && (Simetrica(a,i,j-1,m)));
        else
            return ((a[i][j] == a[j][i]) && (Simetrica(a,i-1,m-1,m-1)));

}
