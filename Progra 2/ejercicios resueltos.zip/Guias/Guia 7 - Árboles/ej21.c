#include <stdio.h>
#include <stdlib.h>

typedef struct nodoA
{
    int dato;
    struct nodoA *izq, *der;
} NodoA;

typedef NodoA* TArbol;

void addNodo(TArbol* A, int x);

int BosqueAlturaK(TArbol A, int K);

int AltArbol(TArbol A);

int main()
{
    TArbol A;
    int K;
    addNodo(&A, 30);
    addNodo(&(A->izq), 10);
    addNodo(&(A->izq->izq), 15);
    addNodo(&(A->der), 40);
    addNodo(&(A->der->der), 43);
    addNodo(&(A->der->izq), 35);
    addNodo(&(A->der->izq->izq), 37);
    addNodo(&(A->der->izq->izq->izq), 17);
    addNodo(&(A->der->der->izq), 41);
    printf("Ingrese K.\n");
    scanf("%d",&K);
    printf("\n*****\n");
    printf("La cantidad de arboles en el bosque original que tienen altura de al menos %d es %d.",K,BosqueAlturaK(A,K));
    printf("\n*****\n");
    return 0;
}

void addNodo(TArbol* A, int x)
{
    *A = (TArbol) malloc(sizeof(NodoA));
    (*A)->dato = x;
    (*A)->der = (*A)->izq = NULL;
}

int BosqueAlturaK(TArbol A, int K)
{
    int cant = 0;
    while (A != NULL)
    {
        cant += (AltArbol(A->izq) >= K-1);
        A = A->der;
    }
    return cant;
}

int AltArbol(TArbol A)
{
    int izq, der;
    if ((A == NULL) || (A->izq == NULL))
        return 0;
    else
    {
        izq = 1 + AltArbol(A->izq);
        der = AltArbol(A->der);
        return (izq>=der)?izq:der;
    }
}
