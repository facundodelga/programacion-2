#include <stdio.h>
#include <stdlib.h>
#include "ArbolesN.h"

//ejercicio a
int cantNodos(TArbol A, TPos pos);

//ejercicio b
void clavesPares(TArbol A, TPos pos, int* pares, int* total);

//ejercicio c
int grado(TArbol A, TPos pos, int max);

//ejercicio d
int cantImpNivImp(TArbol A, TPos pos, int nivel);

//ejercicio e
int cantHijosDatoInt(TArbol A, TPos pos);

void cantHijosDatoVoid(TArbol A, TPos pos, int* todos);

//ejercicio f
void sumaNivelK(TArbol A, TPos pos, int K, int nivelAct, int* suma, int* cant);

int main()
{
    TArbol A;
	int suma = 0, pares = 0, total = 0, porcPares = 0, todos, promedio = 0, K;
	//ejercicio a
	printf("La cantidad de nodos del arbol es: %d\n", cantNodos(A,Raiz(A)));
	printf("\n*****\n");
	//ejercicio b
	clavesPares(A,Raiz(A),&pares,&total);
	if (total != 0)
		porcPares = 100 * (pares / total);
	printf("El porcentaje de claves pares en el arbol es: %d\n",porcPares);
	printf("\n*****\n");
	//ejercicio c
	printf("El grado del arbol es: %d\n",grado(A,Raiz(A),0));
	printf("\n*****\n");
	//ejercicio d
	printf("La cantidad de claves con grado impar en niveles impares es: %d\n", cantImpNivImp(A,Raiz(A),0));
	printf("\n*****\n");
	//ejercicio e
	cantHijosDatoVoid(A,Raiz(A),&todos);
	printf("Todas las claves corresponden a su cantidad de hijos?\nVoid: %d\nInt: %d\n",todos,cantHijosDatoInt(A,Raiz(A)));
	printf("\n*****\n");
	//ejercicio f
	printf("Ingrese K.\n");
	scanf("%d",&K);
	total = 0;
	sumaNivelK(A,Raiz(A),K,1,&suma,&total);
	if (total != 0)
		promedio = suma / total;
	printf("El promedio de las claves en el nivel %d es %d.\n",K,promedio);
    return 0;
}

//ejercicio a
int cantNodos(TArbol A, TPos pos)
{
	int cant = 1;
	TPos act;
	if (Nulo(pos))
		return 0;
	else
	{
		act = HijoMasIzq(pos,A);
		while (!Nulo(act))
		{
			cant += cantNodos(A,act);
			act = HnoDer(pos,A);
		}
		return cant;
	}
}

//ejercicio b
void clavesPares(TArbol A, TPos pos, int* pares, int* total)
{
	TPos act;
	if (!Nulo(pos))
	{
		(*total)++;
		(*pares) += ((Info(pos,A) % 2) == 0);
		act = HijoMasIzq(pos,A);
		while (!Nulo(act))
		{
			clavesPares(A,act,pares,total);
			act = HnoDer(act,A);
		}
	}
}

//ejercicio c
int grado(TArbol A, TPos pos, int max)
{
	int grAct = 0, aux;
	TPos act;
	if (Nulo(pos))
		return 0;
	else
	{
		act = HijoMasIzq(pos,A);
		while (!Nulo(act))
		{
			grAct++;
			if (grAct > max)
				max = grAct;
			aux = grado(A,act,max);
			if (aux > max)
				max = aux;
			act = HnoDer(act,A);
		}
		return max;
	}
}

//ejercicio d
int cantImpNivImp(TArbol A, TPos pos, int nivel)
{
	TPos act;
	int cant = 0, grado = 0;
	if (Nulo(pos))
		return 0;
	else
	{
		nivel++;
		act = HijoMasIzq(pos,A);
		while (!Nulo(act))
		{
			grado++;
			cant += cantImpNivImp(A,act,nivel);
			act = HnoDer(act,A);
		}
		return cant + (((grado % 2) != 0) && ((nivel % 2) != 0));
	}
}

//ejercicio e
int cantHijosDatoInt(TArbol A, TPos pos)
{
	TPos act;
	int todos = 1, grado = 0;
	if (Nulo(pos))
		return 1;
	else
	{
		act = HijoMasIzq(pos,A);
		if (Nulo(act))
			return 1;
		else
		{
			while ((!Nulo(act)) && todos)
			{
				grado++;
				todos = cantHijosDatoInt(A,act);
				act = HnoDer(act,A);
			}
			return (todos && (grado == Info(pos,A)));
		}
	}
}


//TENGO DUDA, NO COPIAR//
void cantHijosDatoVoid(TArbol A, TPos pos, int* todos)
{
	TPos act;
	int grado = 0;
	if (Nulo(pos))
		*todos = 1;
	else
	{
		act = HijoMasIzq(pos,A);
		if (Nulo(act))
			*todos = 1;
		else
		{
			while ((!Nulo(act)) && (*todos))
			{
				grado++;
				cantHijosDatoVoid(A,act,todos);
				act = HnoDer(act,A);
			}
			if (grado != Info(pos,A))
				*todos = 0;
		}
	}
}

//ejercicio f
void sumaNivelK(TArbol A, TPos pos, int K, int nivelAct, int* suma, int* cant)
{
	TPos act;
	if (!Nulo(pos))
	{
		act = HijoMasIzq(pos,A);
		if (nivelAct == K-1)
			while (!Nulo(act))
			{
				(*cant)++;
				(*suma) += Info(act, A);
				act = HnoDer(act,A);
			}
		else
			if (nivelAct < K-1)
				while (!Nulo(act))
				{
					sumaNivelK(A,act,K,nivelAct+1,suma,cant);
					act = HnoDer(act,A);
				}
	}
}
