#include <stdio.h>
#include <stdlib.h>

typedef struct nodoA
{
    int dato;
    struct nodoA *izq, *der;
} NodoA;

typedef NodoA* TArbol;

void addNodo(TArbol* A, int x);

int cantArboles(TArbol A);

int main()
{
    TArbol A;
    int x;
    addNodo(&A, 30);
    addNodo(&(A->izq), 10);
    addNodo(&(A->izq->izq), 15);
    addNodo(&(A->der), 40);
    addNodo(&(A->der->der), 43);
    addNodo(&(A->der->izq), 35);
    addNodo(&(A->der->izq->izq), 37);
    addNodo(&(A->der->der->izq), 41);
    printf("La cantidad de arboles en el bosque original es %d.",cantArboles(A));
    printf("\n*****\n");
    return 0;
}

void addNodo(TArbol* A, int x)
{
    *A = (TArbol) malloc(sizeof(NodoA));
    (*A)->dato = x;
    (*A)->der = (*A)->izq = NULL;
}

int cantArboles(TArbol A)
{
    if (A == NULL)
        return 0;
    else
        return 1 + cantArboles(A->der);
}
