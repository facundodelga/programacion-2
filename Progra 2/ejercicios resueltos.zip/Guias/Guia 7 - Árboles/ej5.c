#include <stdio.h>
#include <stdlib.h>
#define N 100

typedef struct nodoA
{
    int dato;
    struct nodoA *izq, *der;
} NodoA;

typedef NodoA* TArbol;

int Alt(TArbol A);

int Max(TArbol A);

int CantHD(TArbol A);

int main()
{
    TArbol A, aux;
    aux = (TArbol) malloc(sizeof(NodoA));
    aux->dato = 17;
    aux->der = (TArbol) malloc(sizeof(NodoA));
    aux->der->dato = 5;
    aux->izq = (TArbol) malloc(sizeof(NodoA));
    aux->izq->dato = 2;
    aux->der->der = (TArbol) malloc(sizeof(NodoA));
    aux->der->der->dato = 4;
    aux->der->der->izq = aux->der->der->der = NULL;
    aux->der->izq = (TArbol) malloc(sizeof(NodoA));
    aux->der->izq->dato = 36;
    aux->der->izq->der = (TArbol) malloc(sizeof(NodoA));
    aux->der->izq->der->dato = 7;
    aux->der->izq->der->izq = NULL;
    aux->der->izq->der->der = (TArbol) malloc(sizeof(NodoA));
    aux->der->izq->der->der->dato = 22;
    aux->der->izq->der->der->der = aux->der->izq->der->der->izq = NULL;
    aux->der->izq->izq = NULL;
    aux->izq->izq = (TArbol) malloc(sizeof(NodoA));
    aux->izq->izq->dato = 9;
    aux->izq->der = (TArbol) malloc(sizeof(NodoA));
    aux->izq->der->dato = 3;
    aux->izq->der->der = aux->izq->der->izq = NULL;
    aux->izq->izq->izq = (TArbol) malloc(sizeof(NodoA));
    aux->izq->izq->izq->dato = 12;
    aux->izq->izq->izq->der = aux->izq->izq->izq->izq = NULL;
    aux->izq->izq->der = (TArbol) malloc(sizeof(NodoA));
    aux->izq->izq->der->dato = 11;
    aux->izq->izq->der->izq = aux->izq->izq->der->der = NULL;
    A = aux;
    printf("Profundidad/Altura: %d",Alt(A));
    printf("\n*****\n");
    printf("Max: %d", Max(A));
    printf("\n*****\n");
    printf("La cantidad de hijos a derecha es: %d",CantHD(A));
    return 0;
}

int Alt(TArbol A)
{
    int izq, der;
    if ((A == NULL) || ((A->izq == NULL) && (A->der == NULL)))
        return 0;
    else
    {
        izq = Alt(A->izq);
        der = Alt(A->der);
        return 1 + ((izq > der)?izq:der);
    }
}

int Max(TArbol A)
{
    int Der, Izq;
    if (A == NULL)
        return -2000000000;
    else
    {
        Der = Max(A->der);
        Izq = Max(A->izq);
        if ((A->dato > Izq) && (A->dato > Der))
            return A->dato;
        else
            return (Der > Izq)?Der:Izq;
    }
}

int CantHD(TArbol A)
{
    if (A == NULL)
        return 0;
    else
        return CantHD(A->izq) + ((A->der == NULL)? 0 : (CantHD(A->der) + 1));
}
