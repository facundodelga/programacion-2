#include <stdio.h>
#include <stdlib.h>

typedef struct nodoA
{
    int dato;
    struct nodoA *izq, *der;
} NodoA;

typedef NodoA* TArbol;

int SumaMult3(TArbol A);

int CantHojas(TArbol A);

int Busca(TArbol A, int X);

int main()
{
    TArbol A, aux;
    int X;
    aux = (TArbol) malloc(sizeof(NodoA));
    aux->dato = 17;
    aux->der = (TArbol) malloc(sizeof(NodoA));
    aux->der->dato = 5;
    aux->izq = (TArbol) malloc(sizeof(NodoA));
    aux->izq->dato = 2;
    aux->der->der = (TArbol) malloc(sizeof(NodoA));
    aux->der->der->dato = 4;
    aux->der->der->izq = aux->der->der->der = NULL;
    aux->der->izq = (TArbol) malloc(sizeof(NodoA));
    aux->der->izq->dato = 6;
    aux->der->izq->izq = aux->der->izq->der = NULL;
    aux->izq->izq = (TArbol) malloc(sizeof(NodoA));
    aux->izq->izq->dato = 9;
    aux->izq->der = (TArbol) malloc(sizeof(NodoA));
    aux->izq->der->dato = 3;
    aux->izq->der->der = aux->izq->der->izq = NULL;
    aux->izq->izq->izq = (TArbol) malloc(sizeof(NodoA));
    aux->izq->izq->izq->dato = 12;
    aux->izq->izq->izq->der = aux->izq->izq->izq->izq = NULL;
    aux->izq->izq->der = (TArbol) malloc(sizeof(NodoA));
    aux->izq->izq->der->dato = 11;
    aux->izq->izq->der->izq = aux->izq->izq->der->der = NULL;
    A = aux;
    printf("Suma multiplos de 3: %d\tCant Hojas: %d",SumaMult3(A),CantHojas(A));
    printf("\n*****\n");
    printf("Ingrese el elemento a buscar.\n");
    scanf("%d",&X);
    printf("%d est� en el �rbol? %d\n",X, Busca(A,X));
    return 0;
}

int SumaMult3(TArbol A)
{
    if (A == NULL)
        return 0;
    else
    {
        if (A->dato % 3 == 0)
            return SumaMult3(A->der) + SumaMult3(A->izq) + A->dato;
        else
            return SumaMult3(A->der) + SumaMult3(A->izq);
    }
}

int CantHojas(TArbol A)
{
    if (A == NULL)
        return 0;
    else 
	if ((A->der == NULL) && (A->izq == NULL))
        	return 1;
    	else
        	return CantHojas(A->izq) + CantHojas(A->der);
}

int Busca(TArbol A, int X)
{
    if (A == NULL)
        return 0;
    else if (A->dato == X)
        return 1;
    else
        return (Busca(A->izq, X) || Busca(A->der, X));
}
