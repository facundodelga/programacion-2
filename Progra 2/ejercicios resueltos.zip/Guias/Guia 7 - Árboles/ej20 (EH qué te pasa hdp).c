#include <stdio.h>
#include <stdlib.h>

typedef struct nodoA
{
    int dato;
    struct nodoA *izq, *der;
} NodoA;

typedef NodoA* TArbol;

void addNodo(TArbol* A, int x);

int altGeneral(TArbol A);

int main()
{
    TArbol A;
    addNodo(&A, 30);
    addNodo(&(A->izq), 25);
    addNodo(&(A->izq->izq), 7);
    addNodo(&(A->izq->izq->der), 4);
    addNodo(&(A->izq->izq->der->der), 5);
    addNodo(&(A->izq->izq->der->der->der), 6);
    addNodo(&(A->izq->der), 27);
    addNodo(&(A->izq->der->izq), 22);
    addNodo(&(A->izq->der->izq->der), 1);
    addNodo(&(A->izq->der->izq->der->izq), 17);
    addNodo(&(A->izq->der->der), 44);
    addNodo(&(A->izq->der->der->izq), 28);
    printf("\n*****\n");
    printf("La altura del arbol general original es %d.",altGeneral(A));
    return 0;
}

void addNodo(TArbol* A, int x)
{
    *A = (TArbol) malloc(sizeof(NodoA));
    (*A)->dato = x;
    (*A)->der = (*A)->izq = NULL;
}

int altGeneral(TArbol A)
{
    int izq, der;
    if (A == NULL)
        return 0;
    else
    {
        izq = altGeneral(A->izq);
        der = altGeneral(A->der);
        if (izq >= der)
            return izq + (A->izq != NULL);
        else
            return der;
    }
}
