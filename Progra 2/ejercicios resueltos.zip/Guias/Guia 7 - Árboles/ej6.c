#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define N 20

typedef struct nodoA
{
    char dato[20];
    struct nodoA *izq, *der;
} NodoA;

typedef NodoA* TArbol;

void addNodo(TArbol* A, char x[]);

void NivelA(TArbol A, int* max, int* nivelMax, int nivelAct);

int main()
{
    char cad[] = "Arbol";
    int max = 0, nivelMax = 0;
    TArbol A;
    addNodo(&A, cad);
    strcpy(cad, "Bola");
    addNodo(&(A->izq), cad);
    strcpy(cad, "Culo");
    addNodo(&(A->izq->izq), cad);
    strcpy(cad, "Choca");
    addNodo(&(A->izq->der), cad);
    strcpy(cad, "Anterior");
    addNodo(&(A->izq->der->der), cad);
    strcpy(cad, "Celular");
    addNodo(&(A->izq->der->der->izq), cad);
    strcpy(cad, "Loca");
    addNodo(&(A->der), cad);
    strcpy(cad, "Monje");
    addNodo(&(A->der->izq), cad);
    strcpy(cad, "Hijo");
    addNodo(&(A->der->der), cad);
    strcpy(cad, "De");
    addNodo(&(A->der->der->der), cad);
    strcpy(cad, "Puta");
    addNodo(&(A->der->der->der->der), cad);
    printf("\n*****\n");
    NivelA(A,&max,&nivelMax,1);
    printf("%d",nivelMax);
    return 0;
}

void addNodo(TArbol* A, char x[])
{
    *A = (TArbol) malloc(sizeof(NodoA));
    strcpy((*A)->dato,x);
    (*A)->der = (*A)->izq = NULL;
}

void NivelA(TArbol A, int* max, int* nivelMax, int nivelAct)
{
    int leng;
    if (A != NULL)
    {
        leng = strlen(A->dato);
        if (((A->dato[0] == 'A') || (A->dato[0] == 'a')) && (leng > *max))
        {
            *max = leng;
            *nivelMax = nivelAct;
        }
        NivelA(A->izq,max,nivelMax,nivelAct+1);
        NivelA(A->der,max,nivelMax,nivelAct+1);
    }
}
