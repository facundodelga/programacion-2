#include <stdio.h>
#include <stdlib.h>

typedef struct nodoA
{
    int dato;
    struct nodoA *izq, *der;
} NodoA;

typedef NodoA* TArbol;

void addNodo(TArbol* A, int x);

int cantInter(TArbol A, int a, int b);

int main()
{
    TArbol A;
    int a, b;
    addNodo(&A, 30);
    addNodo(&(A->izq), 10);
    addNodo(&(A->izq->der), 15);
    addNodo(&(A->der), 40);
    addNodo(&(A->der->der), 43);
    addNodo(&(A->der->izq), 35);
    addNodo(&(A->der->izq->der), 37);
    addNodo(&(A->der->der->izq), 41);
    printf("\n*****\n");
    printf("Ingrese los valores del intervalo (en orden).\n");
    scanf("%d %d",&a,&b);
    printf("\n*****\n");
    printf("%d elementos del arbol se encuentran entre %d y %d.", cantInter(A,a,b),a,b);
    return 0;
}

void addNodo(TArbol* A, int x)
{
    *A = (TArbol) malloc(sizeof(NodoA));
    (*A)->dato = x;
    (*A)->der = (*A)->izq = NULL;
}

int cantInter(TArbol A, int a, int b)
{
    if (A == NULL)
        return 0;
    else
        if (A->dato <= a)
            return cantInter(A->der,a,b);
        else
            if (A->dato >= b)
                return cantInter(A->izq,a,b);
            else
                return cantInter(A->izq,a,b) + cantInter(A->der,a,b) + 1;
}
