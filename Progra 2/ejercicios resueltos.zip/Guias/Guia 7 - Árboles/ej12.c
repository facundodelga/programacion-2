#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct nodoA
{
    int dato;
    struct nodoA *izq, *der;
} NodoA;

typedef NodoA* TArbol;

void addNodo(TArbol* A, int x);

int Min(TArbol A);

int main()
{
    TArbol A;
    addNodo(&A, 30);
    addNodo(&(A->izq), 10);
    addNodo(&(A->izq->der), 15);
    addNodo(&(A->der), 40);
    addNodo(&(A->der->der), 43);
    addNodo(&(A->der->izq), 35);
    addNodo(&(A->der->izq->der), 37);
    addNodo(&(A->der->der->izq), 41);
    printf("\n*****\n");
    printf("El minimo del arbol es %d.", Min(A));
    return 0;
}

void addNodo(TArbol* A, int x)
{
    *A = (TArbol) malloc(sizeof(NodoA));
    (*A)->dato = x;
    (*A)->der = (*A)->izq = NULL;
}

int Min(TArbol A)
{
    if (A->izq == NULL)
        return A->dato;
    else
        return Min(A->izq);
}
