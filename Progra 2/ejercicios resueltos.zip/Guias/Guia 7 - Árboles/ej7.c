#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define N 20

typedef struct nodoA
{
    int dato;
    struct nodoA *izq, *der;
} NodoA;

typedef NodoA* TArbol;

void addNodo(TArbol* A, char x[]);

int SumaNivelG1(TArbol A, int nivelAct, int X);

int main()
{
    TArbol A, aux;
    int X;
    aux = (TArbol) malloc(sizeof(NodoA));
    aux->dato = 17;
    aux->der = (TArbol) malloc(sizeof(NodoA));
    aux->der->dato = 5;
    aux->izq = (TArbol) malloc(sizeof(NodoA));
    aux->izq->dato = 2;
    aux->der->der = (TArbol) malloc(sizeof(NodoA));
    aux->der->der->dato = 4;
    aux->der->der->izq = aux->der->der->der = NULL;
    aux->der->izq = (TArbol) malloc(sizeof(NodoA));
    aux->der->izq->dato = 6;
    aux->der->izq->der = (TArbol) malloc(sizeof(NodoA));
    aux->der->izq->der->dato = 7;
    aux->der->izq->der->izq = NULL;
    aux->der->izq->der->der = (TArbol) malloc(sizeof(NodoA));
    aux->der->izq->der->der->dato = 2;
    aux->der->izq->der->der->der = aux->der->izq->der->der->izq = NULL;
    aux->der->izq->izq = NULL;
    aux->izq->izq = (TArbol) malloc(sizeof(NodoA));
    aux->izq->izq->dato = 9;
    aux->izq->der = (TArbol) malloc(sizeof(NodoA));
    aux->izq->der->dato = 3;
    aux->izq->der->der = aux->izq->der->izq = NULL;
    aux->izq->izq->izq = (TArbol) malloc(sizeof(NodoA));
    aux->izq->izq->izq->dato = 12;
    aux->izq->izq->izq->der = aux->izq->izq->izq->izq = NULL;
    aux->izq->izq->der = NULL;
    A = aux;
    printf("\n*****\n");
    printf("Ingrese el nivel a buscar.\n");
    scanf("%d",&X);
    printf("La suma de los nodos de grado 1 del nivel %d es %d.\n", X, SumaNivelG1(A,1,X));
    return 0;
}

int SumaNivelG1(TArbol A, int nivelAct, int X)
{
    if ((A != NULL) && (nivelAct < X))
        return SumaNivelG1(A->izq, nivelAct+1, X) + SumaNivelG1(A->der, nivelAct+1, X);
    else
        if (A != NULL)
            if ((A->der == NULL) != (A->izq == NULL))
                return A->dato;
            else
                return 0;
        else
            return 0;
}
