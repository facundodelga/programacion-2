#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define N 20

typedef struct nodoA
{
    int dato;
    struct nodoA *izq, *der;
} NodoA;

typedef NodoA* TArbol;

void addNodo(TArbol* A, int x);

int AlturaAB(TArbol A);

int main()
{
    TArbol A=NULL;
    addNodo(&A, 1);
    addNodo(&(A->der), 2);
    addNodo(&(A->der->izq), 3);
    addNodo(&(A->der->izq->der), 4);
    addNodo(&(A->der->izq->der->izq), 5);
    addNodo(&(A->der->izq->der->izq->der), 6);
    addNodo(&(A->der->izq->der->izq->der->izq), 9);
    addNodo(&(A->der->izq->der->izq->der->izq->der), 10);
    addNodo(&(A->der->izq->der->izq->der->izq->der->der), 11);
    addNodo(&(A->der->izq->der->izq->der->der), 7);
    addNodo(&(A->der->izq->der->izq->der->der->der), 8);
    addNodo(&(A->der->izq->der->izq->der->der->der->izq), 44);
    printf("La altura del arbol binario es: %d",AlturaAB(A));
    return 0;
}

void addNodo(TArbol* A, int x)
{
    *A = (TArbol) malloc(sizeof(NodoA));
    (*A)->dato=x;
    (*A)->der = (*A)->izq = NULL;
}

int AlturaAB(TArbol A)
{
    int izq,der;
    if (A!=NULL)
    {
        der= AlturaAB(A->der);
        if (A->izq!=NULL)
            izq=1+AlturaAB(A->izq);
        else
            izq=0;
        return izq>der?izq:der;
    }
    else
        return 0;
}


/* INTENTO DE ALTURAAB CON INT, NO PODIA VOLVER PARA DERECHA CUANDO LLEGABA AL 6
{
    if (A==NULL)
        return 0;
    else
    {
       if (A->izq!=NULL || A->der!=NULL)
        {
            if (A->izq==NULL)
                return AlturaAB(A->der,AlturaAct);
            else
                return AlturaAB(A->izq,AlturaAct+1);
        }
        else
            return AlturaAct;
    }
} */
