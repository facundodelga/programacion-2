#include <stdio.h>
#include <stdlib.h>

typedef struct nodoA
{
    int dato;
    struct nodoA *izq, *der;
} NodoA;

typedef NodoA* TArbol;

void addNodo(TArbol* A, int x);

int main()
{
    TArbol A;
    addNodo(&A, 30);
    addNodo(&(A->izq), 25);
    addNodo(&(A->izq->izq), 7);
    addNodo(&(A->izq->izq->der), 4);
    addNodo(&(A->izq->izq->der->der), 5);
    addNodo(&(A->izq->izq->der->der->der), 6);
    addNodo(&(A->izq->der), 27);
    addNodo(&(A->izq->der->izq), 22);
    addNodo(&(A->izq->der->izq->der), 1);
    addNodo(&(A->izq->der->izq->der->izq), 17);
    addNodo(&(A->izq->der->der), 44);
    addNodo(&(A->izq->der->der->izq), 28);
    printf("\n*****\n");
    printf("El grado del arbol general original es %d.",gradoGeneral(A,0));
    return 0;
}

void addNodo(TArbol* A, int x)
{
    *A = (TArbol) malloc(sizeof(NodoA));
    (*A)->dato = x;
    (*A)->der = (*A)->izq = NULL;
}

int gradoGeneral(TArbol A, int gradoAct)
{
    int izq, der;
    if (A == NULL)
        return gradoAct-1;
    else
    {
        izq = gradoGeneral(A->izq, 1);
        der = gradoGeneral(A->der, gradoAct+1);
        if (izq>der)
            return (gradoAct>izq)?gradoAct:izq;
        else
            return (gradoAct>der)?gradoAct:der;

    }
}
