#include <stdio.h>
#include <stdlib.h>
#define N 100

typedef struct nodoA
{
    int dato;
    struct nodoA *izq, *der;
} NodoA;

typedef NodoA* TArbol;

void addNodo(TArbol* A, int x);

void arregloDesc(TArbol A, int v[], int* n);

void muestraVector(int v[], int n);

int main()
{
    TArbol A;
    int v[N], n = -1;
    addNodo(&A, 30);
    addNodo(&(A->izq), 10);
    addNodo(&(A->izq->der), 15);
    addNodo(&(A->der), 40);
    addNodo(&(A->der->der), 43);
    addNodo(&(A->der->izq), 35);
    addNodo(&(A->der->izq->der), 37);
    addNodo(&(A->der->der->izq), 41);
    printf("\n*****\n");
    arregloDesc(A,v,&n);
    muestraVector(v,n);
    return 0;
}

void addNodo(TArbol* A, int x)
{
    *A = (TArbol) malloc(sizeof(NodoA));
    (*A)->dato = x;
    (*A)->der = (*A)->izq = NULL;
}

void arregloDesc(TArbol A, int v[], int* n)
{
    if (A != NULL)
    {
        arregloDesc(A->der,v,n);
        v[++(*n)] = A->dato;
        arregloDesc(A->izq,v,n);
    }
}

void muestraVector(int v[], int n)
{
    int i;
    for (i=0;i<=n;i++)
        printf("%d\t", v[i]);
}
