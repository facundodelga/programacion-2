#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct nodoA
{
    int dato;
    struct nodoA *izq, *der;
} NodoA;

typedef NodoA* TArbol;

void addNodo(TArbol* A, int x);

int busca(TArbol a, int x)
{
    if (a == NULL)
        return 0;
    else
        if(x == a->dato)
            return 1;
        else
            if (x > a->dato)
                return busca(a->der, x);
            else
                return busca(a->izq, x);
}

int main()
{
    TArbol A;
    int x;
    addNodo(&A, 30);
    addNodo(&(A->izq), 10);
    addNodo(&(A->izq->der), 15);
    addNodo(&(A->der), 40);
    addNodo(&(A->der->der), 43);
    addNodo(&(A->der->izq), 35);
    addNodo(&(A->der->izq->der), 37);
    addNodo(&(A->der->der->izq), 41);
    printf("\n*****\n");
    printf("Ingrese el numero a buscar en el arbol.\n");
    scanf("%d",&x);
    printf("%d esta en el arbol? %d", x, busca(A,x));
    return 0;
}

void addNodo(TArbol* A, int x)
{
    *A = (TArbol) malloc(sizeof(NodoA));
    (*A)->dato = x;
    (*A)->der = (*A)->izq = NULL;
}
