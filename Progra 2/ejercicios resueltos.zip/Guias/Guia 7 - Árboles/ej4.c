#include <stdio.h>
#include <stdlib.h>
#define N 100

typedef struct nodoA
{
    int dato;
    struct nodoA *izq, *der;
} NodoA;

typedef NodoA* TArbol;

void arrgrado2(TArbol a, int v[N], int* dimv);

void MuestraVector(int v[N], int dimv);

int main()
{
    TArbol A, aux;
    int dimv = -1, v[N];
    aux = (TArbol) malloc(sizeof(NodoA));
    aux->dato = 17;
    aux->der = (TArbol) malloc(sizeof(NodoA));
    aux->der->dato = 5;
    aux->izq = (TArbol) malloc(sizeof(NodoA));
    aux->izq->dato = 2;
    aux->der->der = (TArbol) malloc(sizeof(NodoA));
    aux->der->der->dato = 4;
    aux->der->der->izq = aux->der->der->der = NULL;
    aux->der->izq = (TArbol) malloc(sizeof(NodoA));
    aux->der->izq->dato = 6;
    aux->der->izq->izq = aux->der->izq->der = NULL;
    aux->izq->izq = (TArbol) malloc(sizeof(NodoA));
    aux->izq->izq->dato = 9;
    aux->izq->der = (TArbol) malloc(sizeof(NodoA));
    aux->izq->der->dato = 3;
    aux->izq->der->der = aux->izq->der->izq = NULL;
    aux->izq->izq->izq = (TArbol) malloc(sizeof(NodoA));
    aux->izq->izq->izq->dato = 12;
    aux->izq->izq->izq->der = aux->izq->izq->izq->izq = NULL;
    aux->izq->izq->der = (TArbol) malloc(sizeof(NodoA));
    aux->izq->izq->der->dato = 11;
    aux->izq->izq->der->izq = aux->izq->izq->der->der = NULL;
    A = aux;
    arrgrado2(A, v, &dimv);
    MuestraVector(v,dimv);
    return 0;
}

void arrgrado2(TArbol a, int v[N], int* dimv)
{
    if (a != NULL)
    {
        if(a->izq != NULL && a->der != NULL)  /* grado 2 */
            v[++(*dimv)] = a->dato;
        arrgrado2(a->izq, v, dimv);
        arrgrado2(a->der, v, dimv);
    }
}

void MuestraVector(int v[N], int dimv)
{
    int i;
    for (i=0;i<=dimv;i++)
        printf("%d\t",v[i]);
}
