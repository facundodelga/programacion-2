#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define N 20

typedef struct nodoA
{
    char dato[20];
    struct nodoA *izq, *der;
} NodoA;

typedef NodoA* TArbol;

void addNodo(TArbol* A, char x[]);

void Ganador(TArbol A);

void Finalistas(TArbol A);

void Semifinalistas(TArbol A);

void Competidores(TArbol A, int* cant);

int main()
{
    int cant = 0;
    TArbol A;
    char cad[N] = "Robert";
    addNodo(&A, cad);
    addNodo(&(A->izq), cad);
    addNodo(&(A->izq->der), cad);
    addNodo(&(A->izq->der->izq), cad);
    strcpy(cad, "Negro");
    addNodo(&(A->izq->izq), cad);
    addNodo(&(A->izq->izq->izq), cad);
    strcpy(cad, "Cazorla");
    addNodo(&(A->izq->izq->der), cad);
    strcpy(cad, "Claudio");
    addNodo(&(A->izq->der->der), cad);
    strcpy(cad, "Picha");
    addNodo(&(A->der), cad);
    addNodo(&(A->der->der), cad);
    addNodo(&(A->der->der->der), cad);
    strcpy(cad, "Nacho");
    addNodo(&(A->der->izq), cad);
    addNodo(&(A->der->izq->izq), cad);
    strcpy(cad, "Lucas");
    addNodo(&(A->der->izq->der), cad);
    strcpy(cad, "Matias");
    addNodo(&(A->der->der->izq), cad);
    printf("\n*****\n");
    Ganador(A);
    printf("\n*****\n");
    Finalistas(A);
    printf("\n*****\n");
    Semifinalistas(A);
    printf("\n*****\n");
    Competidores(A, &cant);
    printf("\nCantidad de competidores: %d\n", cant);
    return 0;
}

void addNodo(TArbol* A, char x[])
{
    *A = (TArbol) malloc(sizeof(NodoA));
    strcpy((*A)->dato,x);
    (*A)->der = (*A)->izq = NULL;
}

void Ganador(TArbol A)
{
    if (A != NULL)
        printf("El ganador es %s.\n", A->dato);
}

void Finalistas(TArbol A)
{
    if (A != NULL)
    {
        printf("Los finalistas son ");
        if (A->izq != NULL)
            printf("%s y ", A->izq->dato);
        if (A->der != NULL)
            printf("%s.\n", A->der->dato);
    }
}

void Semifinalistas(TArbol A)
{
    if (A!= NULL)
    {
        printf("Los semifinalistas son: ");
        if (A->izq != NULL)
        {
            if (A->izq->izq != NULL)
                printf("%s, ", A->izq->izq->dato);
            if (A->izq->der != NULL)
                printf("%s, ", A->izq->der->dato);
        }
        if (A->der != NULL)
        {
            if (A->der->izq != NULL)
                printf("%s, ", A->der->izq->dato);
            if (A->der->der != NULL)
                printf("%s", A->der->der->dato);
        }
    }
}

void Competidores(TArbol A, int* cant)
{
    if (A != NULL)
        if ((A->der == NULL) && (A->izq == NULL))
        {
            printf("%s\t\t", A->dato);
            (*cant)++;
        }
        else
        {
            Competidores(A->izq, cant);
            Competidores(A->der, cant);
        }
}
