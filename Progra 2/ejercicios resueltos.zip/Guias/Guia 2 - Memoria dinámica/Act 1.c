#include <stdio.h>
#include <stdlib.h>
#include <string.h>

//Act 1 guia 2

void ordenadas(int *x,int *y);
int main()
{
    int a=30,b=20;
    printf(" valor de a %d\t valor de b %d\n",a,b);
    ordenadas(&a,&b);
    printf(" valor de a %d\t valor de b %d\n",a,b);
    return 0;
}
void ordenadas(int *x,int *y)
{
    int aux;
    if (x>y){
        aux=*x;
        *x=*y;
        *y=aux;
    }
}


