#include <stdio.h>
#include <stdlib.h>
#define Freeze free(c)

int suma(int *a,int *b,int *c);

int multiplicacion(int *a,int *b,int *c);

void CreaVar(int **a);

int main()
{
    int *a, *b, *c;
    CreaVar(&a);
    CreaVar(&b);
    CreaVar(&c);
    printf("La suma es %d\n",suma(a,b,c));
    printf("La multiplicacion es %d",multiplicacion(a,b,c));
    free(a);
    free(b);
    Freeze;
    return 0;
}

int suma(int *a,int *b,int *c)
{
    return(*a+*b+*c);
}

int multiplicacion(int *a,int *b,int *c)
{
    return(*a * *b * *c);
}

void CreaVar(int **a)
{
    *a = (int *) malloc(sizeof(int));
    printf("Ingrese su n�mero se�ora. SE�ORAAAAAAAA\n");
    scanf("%d",*a);
}
