#include <stdio.h>
#include <stdlib.h>
#include <string.h>

//Guia 2/Act 4
void Muestra(int *p,int n);
int main()
{
    int n,i=0;
    int *p;
    printf("Ingrese la N cantidad de elementos:\n");
    scanf("%d",&n);
    p=(int*)malloc(n*sizeof(int));
    while (i<n)
    {
        scanf("%d",p+(i++));
    }
    Muestra(p,n);
    free(p);
    return 0;
}
void Muestra(int *p,int n)
{
    for (int k=0;k<n;k++)
        if (*(p+k)>0)
            printf("%d\t",*(p+k));
}
