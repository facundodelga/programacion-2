#include <stdio.h>
#include <stdlib.h>

void Muestra(int *v[], int i);

int main()
{
    int *v[20];
    int i=0,j,k;
    FILE * Arch;
    Arch = fopen("ej5.txt","rt");
    if (Arch == NULL)
        printf("No se encontr� el archivo ej5.txt");
    else
    {
        while (fscanf(Arch,"%d",&k) == 1)
        {
            v[i] = (int *) malloc(sizeof(int));
            *v[i++] = k;
        }
        Muestra(v,i);
        for (j=0;j<i;j++)
            free(v[j]);
    }
}

void Muestra(int *v[], int i)
{
    int j;
    for (j=0;j<i;j++)
        if (*v[j] > 0)
            printf(" %d",*v[j]);
}
