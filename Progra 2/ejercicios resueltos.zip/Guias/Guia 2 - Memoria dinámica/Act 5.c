#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define N 10

//Guia 2/Act 5
void Muestra(int V[N],int i);

int main()
{
    int V[N];
    int *p;
    int i=0;
    FILE *arch;
    arch=fopen("act5tp2.txt","rt");
    if (arch==NULL)
        printf("No abri�\n");
    else
    {
        p=(int*)malloc(sizeof(int));
        fscanf(arch,"%p",p);
        while (!feof(arch))
        {
            V[i++]=*p;
            p=(int*)malloc(sizeof(int));
            fscanf(arch,"%p",p);
        }
    }
    fclose(arch);
    Muestra(V,i);
    free(p);
    return 0;
}
void Muestra(int V[N],int i){
    for (int k=0;k<i;k++)
        if (V[k]>0)
            printf("%d\t",V[k]);
    }
