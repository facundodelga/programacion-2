#include <stdio.h>
#include <stdlib.h>

int main()
{
    unsigned int N, i;
    float *V;
    printf("Ingrese la cantidad de n�meros reales a analizar.\n");
    scanf("%u",&N);
    V = (float *) malloc((sizeof(float))*N);
    printf("Ingrese los n�meros reales a analizar.\n");
    for (i=0;i<N;i++)
        scanf("%f",(V+i));
    printf("*****\nLos n�meros positivos ingresados son:\n");
    for (i=0;i<N;i++)
    {
        if ((*(V+i))>0)
            printf("%7.2f",*(V+i));
    }
    free(V);
    return 0;
}
