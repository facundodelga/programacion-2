#include <stdio.h>
#include <stdlib.h>
#include <string.h>

//Act 2 guia 2

int main()
{
    int *p, a = 4, b = 5;
    p = &b;
    *p *= 2;
    printf("b=%d *p=%d\n", b, *p); //__b=10 *p=10_______________
    printf("&b=%p p=%p &p=%p\n", &b, p, &p); //&b=0060FEF4 p=0060FEF4 &p=0060FEFC_______________
    b = *p *3;
    printf("b=%d *p=%d\n", b, *p); //__b=30 *p=30_______________
    printf("&b=%p p=%p\n", &b, p); //__b=0060FEF4 p=0060FEF4_______
    a = b;
    p = &a;
    (*p)++;
    printf("b=%d a=%d *p=%d\n", b, a, *p); //__30 31 31_______________
    printf("&b=%p &a=%p p=%p &p=%p\n", &b, &a, p, &p); //_&b=0060FEF4 &a=0060FEF8 p=0060FEF8 &p=0060FEFC______
}



